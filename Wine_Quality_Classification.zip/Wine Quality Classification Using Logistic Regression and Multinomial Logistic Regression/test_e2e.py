import urllib.request
import json

print("=== 1. Testing Vite Frontend HTTP Serving ===")
frontend_html = urllib.request.urlopen("http://127.0.0.1:5173/").read().decode()
assert "Wine Quality Classification" in frontend_html
print("Vite Frontend Serving index.html OK! Title verified.")

print("\n=== 2. Testing FastAPI Health ===")
health = json.loads(urllib.request.urlopen("http://127.0.0.1:8000/health").read().decode())
print("Health status:", health)

print("\n=== 3. Testing Sample Dataset Loading ===")
req = urllib.request.Request(
    "http://127.0.0.1:8000/load-sample",
    data=json.dumps({"sample_type": "red"}).encode("utf-8"),
    headers={"Content-Type": "application/json"}
)
sample_res = json.loads(urllib.request.urlopen(req).read().decode())
print(f"Loaded: {sample_res['filename']}, Rows: {sample_res['rows']}, Cols: {sample_res['columns']}, Classes: {sample_res['classes']}")

print("\n=== 4. Testing Preprocessing Pipeline ===")
req_prep = urllib.request.Request(
    "http://127.0.0.1:8000/preprocess",
    data=json.dumps({"remove_duplicates": True, "test_size": 0.2, "random_state": 42}).encode("utf-8"),
    headers={"Content-Type": "application/json"}
)
prep_res = json.loads(urllib.request.urlopen(req_prep).read().decode())
print(f"Rows before: {prep_res['rows_before']}, Duplicates removed: {prep_res['duplicates_removed']}, Rows after: {prep_res['rows_after']}")
print(f"Train samples: {prep_res['train_samples']}, Test samples: {prep_res['test_samples']}")

print("\n=== 5. Testing Model Training (Binary & Multinomial) ===")
req_train = urllib.request.Request(
    "http://127.0.0.1:8000/train",
    data=json.dumps({"threshold": 6.0, "max_iter": 1000}).encode("utf-8"),
    headers={"Content-Type": "application/json"}
)
train_res = json.loads(urllib.request.urlopen(req_train).read().decode())
bin_acc = train_res["binary"]["accuracy"]
bin_auc = train_res["binary"]["roc_auc"]
mul_acc = train_res["multinomial"]["accuracy"]
mul_f1 = train_res["multinomial"]["f1_score"]
print(f"Binary Logistic Regression -> Acc: {bin_acc*100:.2f}%, ROC-AUC: {bin_auc:.4f}")
print(f"Multinomial Logistic Regression -> Acc: {mul_acc*100:.2f}%, Weighted F1: {mul_f1:.4f}")
print(f"Best Model Verdict: {train_res['comparison']['best_model']}")

print("\n=== 6. Testing Prediction API ===")
req_presets = urllib.request.urlopen("http://127.0.0.1:8000/predict/presets")
presets = json.loads(req_presets.read().decode())
print(f"Presets found: {len(presets)}")
sample_feats = presets[0]["values"]
req_pred = urllib.request.Request(
    "http://127.0.0.1:8000/predict",
    data=json.dumps({"features": sample_feats}).encode("utf-8"),
    headers={"Content-Type": "application/json"}
)
pred_res = json.loads(urllib.request.urlopen(req_pred).read().decode())
print(f"Binary prediction: {pred_res['binary_prediction']['prediction']} (confidence {pred_res['binary_prediction']['confidence_percent']}%)")
print(f"Multinomial predicted quality score: {pred_res['multiclass_prediction']['predicted_quality']}")
print(f"Class probability distributions: {len(pred_res['multiclass_prediction']['class_probabilities'])} classes")

print("\n=== 7. Testing Visualizations & Report Endpoints ===")
corr = json.loads(urllib.request.urlopen("http://127.0.0.1:8000/visualizations/correlation").read().decode())
print(f"Correlation matrix: {len(corr['columns'])} features")
dists = json.loads(urllib.request.urlopen("http://127.0.0.1:8000/visualizations/distributions").read().decode())
print(f"Features with histograms: {len(dists['features'])}")
report_text = urllib.request.urlopen("http://127.0.0.1:8000/download/report").read().decode()
assert "WINE QUALITY CLASSIFICATION" in report_text
print(f"Downloadable Project Report OK! Length: {len(report_text)} characters")

print("\n>>> ALL FULL-STACK ENDPOINTS AND ML LOGIC FULLY VALIDATED! <<<")
