import urllib.request
import io
import json

with open("backend/data/winequality-red.xlsx", "rb") as f:
    excel_bytes = f.read()

boundary = "----WebKitFormBoundary7MA4YWxkTrZu0gW"
body = io.BytesIO()
body.write(f"--{boundary}\r\n".encode())
body.write(b'Content-Disposition: form-data; name="file"; filename="winequality-red.xlsx"\r\n')
body.write(b"Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet\r\n\r\n")
body.write(excel_bytes)
body.write(f"\r\n--{boundary}--\r\n".encode())
payload = body.getvalue()

req = urllib.request.Request(
    "http://127.0.0.1:8000/upload",
    data=payload,
    headers={
        "Content-Type": f"multipart/form-data; boundary={boundary}",
        "Content-Length": str(len(payload))
    }
)
res = json.loads(urllib.request.urlopen(req).read().decode())
print("Excel Upload Result:", res["filename"], "Rows:", res["rows"], "Cols:", res["columns"], "Target:", res["target_column"])
print("Excel upload verified 100%!")
