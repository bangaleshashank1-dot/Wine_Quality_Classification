import React, { useState, useEffect } from 'react';
import Sidebar from './components/Sidebar';
import Topbar from './components/Topbar';
import TrainingModal from './components/TrainingModal';

import DashboardPage from './pages/DashboardPage';
import DatasetPage from './pages/DatasetPage';
import PreprocessingPage from './pages/PreprocessingPage';
import BinaryClassificationPage from './pages/BinaryClassificationPage';
import MulticlassClassificationPage from './pages/MulticlassClassificationPage';
import ModelComparisonPage from './pages/ModelComparisonPage';
import PredictionPage from './pages/PredictionPage';
import VisualizationsPage from './pages/VisualizationsPage';
import AboutPage from './pages/AboutPage';

import { api } from './api';

export default function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [isDark, setIsDark] = useState(true);
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);

  // Core ML state
  const [datasetSummary, setDatasetSummary] = useState(null);
  const [preprocessingData, setPreprocessingData] = useState(null);
  const [logisticResults, setLogisticResults] = useState(null);
  const [multinomialResults, setMultinomialResults] = useState(null);
  const [comparisonData, setComparisonData] = useState(null);
  
  const [isTrained, setIsTrained] = useState(false);
  const [isTraining, setIsTraining] = useState(false);
  const [trainingModalOpen, setTrainingModalOpen] = useState(false);

  // Sync dark class on document element
  useEffect(() => {
    if (isDark) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDark]);

  // Initial load check
  useEffect(() => {
    api.checkHealth()
      .then((health) => {
        if (health.dataset_loaded) {
          api.getDataset().then(setDatasetSummary);
        }
        if (health.models_trained) {
          setIsTrained(true);
          Promise.all([
            api.getLogisticResults(),
            api.getMultinomialResults(),
            api.getModelComparison(),
          ]).then(([logRes, multiRes, compRes]) => {
            setLogisticResults(logRes);
            setMultinomialResults(multiRes);
            setComparisonData(compRes);
          });
        }
      })
      .catch((err) => console.log('Backend not ready yet:', err.message));
  }, []);

  // Upload handler
  const handleUploadSuccess = (summary) => {
    setDatasetSummary(summary);
    // Reset previous training
    setIsTrained(false);
    setLogisticResults(null);
    setMultinomialResults(null);
    setComparisonData(null);
    // Automatically navigate to Dataset page per prompt requirements
    setActiveTab('dataset');
  };

  // Remove dataset handler
  const handleRemoveDataset = () => {
    setDatasetSummary(null);
    setPreprocessingData(null);
    setLogisticResults(null);
    setMultinomialResults(null);
    setComparisonData(null);
    setIsTrained(false);
    setActiveTab('dataset');
  };

  // Sample dataset loader
  const handleLoadSample = async (sampleType = 'red') => {
    try {
      const summary = await api.loadSampleDataset(sampleType);
      handleUploadSuccess(summary);
    } catch (err) {
      alert('Failed to load sample dataset: ' + (err.response?.data?.detail || err.message));
    }
  };

  // Train Models Handler
  const handleTrain = async (threshold = 6.0) => {
    if (!datasetSummary) return;

    setIsTraining(true);
    setTrainingModalOpen(true);

    try {
      // 1. Run Preprocessing if not already run
      const prepRes = await api.preprocessData(true, 0.2, 42);
      setPreprocessingData(prepRes);

      // 2. Train Models
      const trainRes = await api.trainModels(threshold, 1000);
      setLogisticResults(trainRes.binary);
      setMultinomialResults(trainRes.multinomial);
      setComparisonData(trainRes.comparison);
      setIsTrained(true);
    } catch (err) {
      alert('Training failed: ' + (err.response?.data?.detail || err.message));
    } finally {
      setIsTraining(false);
    }
  };

  const handleDownloadReport = () => {
    window.open(api.getDownloadReportUrl(), '_blank');
  };

  const renderActivePage = () => {
    switch (activeTab) {
      case 'dashboard':
        return (
          <DashboardPage
            datasetSummary={datasetSummary}
            logisticResults={logisticResults}
            multinomialResults={multinomialResults}
            isTrained={isTrained}
            setActiveTab={setActiveTab}
            onLoadSample={handleLoadSample}
            isDark={isDark}
          />
        );
      case 'dataset':
        return (
          <DatasetPage
            datasetSummary={datasetSummary}
            onUploadSuccess={handleUploadSuccess}
            onRemoveDataset={handleRemoveDataset}
            onTrain={() => handleTrain(6.0)}
            isTraining={isTraining}
            setActiveTab={setActiveTab}
            isDark={isDark}
          />
        );
      case 'preprocessing':
        return (
          <PreprocessingPage
            preprocessingData={preprocessingData}
            datasetSummary={datasetSummary}
            onTrain={() => handleTrain(6.0)}
            isTraining={isTraining}
            isDark={isDark}
          />
        );
      case 'binary':
        return (
          <BinaryClassificationPage
            logisticResults={logisticResults}
            isTrained={isTrained}
            onRetrainWithThreshold={(thresh) => handleTrain(thresh)}
            isTraining={isTraining}
            isDark={isDark}
          />
        );
      case 'multiclass':
        return (
          <MulticlassClassificationPage
            multinomialResults={multinomialResults}
            isTrained={isTrained}
            isDark={isDark}
          />
        );
      case 'comparison':
        return (
          <ModelComparisonPage
            comparisonData={comparisonData}
            isTrained={isTrained}
            isDark={isDark}
          />
        );
      case 'prediction':
        return (
          <PredictionPage
            datasetSummary={datasetSummary}
            preprocessingData={preprocessingData}
            isTrained={isTrained}
            isDark={isDark}
          />
        );
      case 'visualizations':
        return (
          <VisualizationsPage
            datasetSummary={datasetSummary}
            isDark={isDark}
          />
        );
      case 'about':
        return <AboutPage isDark={isDark} />;
      default:
        return null;
    }
  };

  return (
    <div className={`min-h-screen flex transition-colors duration-200 ${
      isDark ? 'bg-slate-950 text-slate-100' : 'bg-slate-50 text-slate-900'
    }`}>
      {/* Desktop Sidebar */}
      <div className="hidden md:flex">
        <Sidebar
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          datasetSummary={datasetSummary}
          isTrained={isTrained}
          isDark={isDark}
        />
      </div>

      {/* Mobile Drawer Sidebar */}
      {mobileSidebarOpen && (
        <div className="fixed inset-0 z-50 flex md:hidden">
          <div
            className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm"
            onClick={() => setMobileSidebarOpen(false)}
          />
          <div className="relative flex-1 max-w-xs w-full">
            <Sidebar
              activeTab={activeTab}
              setActiveTab={(tab) => {
                setActiveTab(tab);
                setMobileSidebarOpen(false);
              }}
              datasetSummary={datasetSummary}
              isTrained={isTrained}
              isDark={isDark}
            />
          </div>
        </div>
      )}

      {/* Main Workspace Area */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <Topbar
          activeTab={activeTab}
          isDark={isDark}
          setIsDark={setIsDark}
          onTrain={() => handleTrain(6.0)}
          isTraining={isTraining}
          onLoadSample={handleLoadSample}
          datasetLoaded={Boolean(datasetSummary?.rows)}
          isTrained={isTrained}
          onDownloadReport={handleDownloadReport}
          onToggleMobileSidebar={() => setMobileSidebarOpen(!mobileSidebarOpen)}
        />

        <main className="flex-1 overflow-y-auto p-4 sm:p-8 max-w-7xl w-full mx-auto">
          {renderActivePage()}
        </main>
      </div>

      {/* Live Training Modal */}
      <TrainingModal
        isOpen={trainingModalOpen}
        isTraining={isTraining}
        onComplete={() => {
          setTrainingModalOpen(false);
          setActiveTab('binary');
        }}
      />
    </div>
  );
}
