import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  Play,
  RotateCcw,
  CheckCircle2,
  AlertTriangle,
  Award,
  Layers,
  HelpCircle,
  FlaskConical
} from 'lucide-react';
import { api } from '../api';

export default function PredictionPage({
  datasetSummary,
  preprocessingData,
  isTrained,
  isDark
}) {
  const [featureInputs, setFeatureInputs] = useState({});
  const [presets, setPresets] = useState([]);
  const [predictionResult, setPredictionResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  // Initialize input fields based on detected features
  useEffect(() => {
    if (datasetSummary && datasetSummary.column_info) {
      const initial = {};
      datasetSummary.column_info.forEach((col) => {
        if (col.name !== datasetSummary.target_column && col.is_numeric) {
          // Default to mean value or min value
          initial[col.name] = col.mean !== null ? col.mean : (col.min || 0);
        }
      });
      setFeatureInputs(initial);
    }
  }, [datasetSummary]);

  // Load sample presets
  useEffect(() => {
    if (isTrained) {
      api.getPredictionPresets()
        .then((data) => setPresets(data))
        .catch((err) => console.error('Failed to load presets:', err));
    }
  }, [isTrained]);

  const handleInputChange = (featureName, value) => {
    setFeatureInputs((prev) => ({
      ...prev,
      [featureName]: value,
    }));
  };

  const loadPreset = (presetValues) => {
    setFeatureInputs({ ...presetValues });
    setPredictionResult(null);
  };

  const handlePredict = async (e) => {
    e.preventDefault();
    setErrorMessage('');
    setLoading(true);

    try {
      // Validate all numerical inputs
      const numericPayload = {};
      for (const [k, v] of Object.entries(featureInputs)) {
        const parsed = parseFloat(v);
        if (isNaN(parsed)) {
          throw new Error(`Feature '${k}' must be a valid numeric number.`);
        }
        numericPayload[k] = parsed;
      }

      const res = await api.predictWine(numericPayload);
      setPredictionResult(res);
    } catch (err) {
      setErrorMessage(
        err.response?.data?.detail || err.message || 'Failed to make prediction. Please check your inputs.'
      );
    } finally {
      setLoading(false);
    }
  };

  const handleReset = () => {
    if (datasetSummary && datasetSummary.column_info) {
      const resetVals = {};
      datasetSummary.column_info.forEach((col) => {
        if (col.name !== datasetSummary.target_column && col.is_numeric) {
          resetVals[col.name] = col.mean !== null ? col.mean : 0;
        }
      });
      setFeatureInputs(resetVals);
      setPredictionResult(null);
      setErrorMessage('');
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-6 rounded-3xl bg-slate-900/60 border border-slate-800">
        <div className="space-y-1">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 rounded-xl bg-amber-500/15 text-amber-400 flex items-center justify-center">
              <Sparkles className="w-4 h-4" />
            </div>
            <h3 className="text-lg font-bold text-slate-100">
              Interactive Wine Quality Prediction
            </h3>
          </div>
          <p className="text-xs text-slate-400">
            Enter chemical laboratory measurements to predict wine quality using trained models.
          </p>
        </div>

        {/* Preset sample buttons */}
        {presets.length > 0 && (
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-[11px] text-slate-400 font-semibold mr-1">Quick Presets:</span>
            {presets.map((p, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => loadPreset(p.values)}
                className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-medium transition-all"
                title={p.description}
              >
                {p.name.includes('High') ? '🍷 Good Wine Preset' : p.name.includes('Low') ? '📉 Poor Wine Preset' : '📊 Average Wine'}
              </button>
            ))}
          </div>
        )}
      </div>

      {!isTrained ? (
        <div className="p-12 rounded-3xl border border-dashed border-slate-800 bg-slate-900/40 text-center space-y-3">
          <AlertTriangle className="w-10 h-10 text-amber-400 mx-auto" />
          <h4 className="text-base font-bold text-slate-200">Models Not Trained Yet</h4>
          <p className="text-xs text-slate-400 max-w-sm mx-auto">
            Please train the Logistic Regression and Multinomial models before making predictions.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Input Form Column (7 cols) */}
          <div className="lg:col-span-7 space-y-6">
            <form onSubmit={handlePredict} className="p-6 rounded-3xl bg-slate-900/60 border border-slate-800 shadow-md space-y-5">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div>
                  <h4 className="text-sm font-bold text-slate-200 uppercase tracking-wider">
                    Physicochemical Input Features
                  </h4>
                  <p className="text-xs text-slate-400">
                    Dynamically mapped from detected dataset features
                  </p>
                </div>

                <button
                  type="button"
                  onClick={handleReset}
                  className="flex items-center space-x-1 text-xs text-slate-400 hover:text-slate-200"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Reset Values</span>
                </button>
              </div>

              {errorMessage && (
                <div className="p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 flex-shrink-0" />
                  <span>{errorMessage}</span>
                </div>
              )}

              {/* Dynamic Grid of Feature Input Fields */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {Object.keys(featureInputs).map((featName) => {
                  const colMeta = datasetSummary?.column_info?.find((c) => c.name === featName);
                  return (
                    <div key={featName} className="space-y-1.5">
                      <div className="flex items-center justify-between">
                        <label className="text-xs font-semibold text-slate-300 capitalize truncate" title={featName}>
                          {featName}
                        </label>
                        {colMeta && (
                          <span className="text-[10px] text-slate-500 font-mono">
                            range: [{colMeta.min}, {colMeta.max}]
                          </span>
                        )}
                      </div>

                      <div className="relative">
                        <input
                          type="number"
                          step="any"
                          value={featureInputs[featName]}
                          onChange={(e) => handleInputChange(featName, e.target.value)}
                          required
                          className="w-full px-3.5 py-2 rounded-xl bg-slate-800/80 border border-slate-700 text-slate-100 font-mono text-xs focus:outline-none focus:border-rose-500 transition-colors"
                          placeholder={colMeta?.mean !== null ? String(colMeta?.mean) : '0.0'}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Submit Button */}
              <div className="pt-3 border-t border-slate-800 flex items-center justify-end gap-3">
                <button
                  type="submit"
                  disabled={loading}
                  className="flex items-center space-x-2 px-6 py-3 rounded-2xl bg-gradient-to-r from-rose-600 via-pink-600 to-rose-600 hover:from-rose-500 hover:to-pink-500 text-white font-bold text-sm shadow-lg shadow-rose-600/30 transition-all disabled:opacity-50"
                >
                  <FlaskConical className="w-4 h-4" />
                  <span>{loading ? 'Evaluating Model...' : 'Predict Wine Quality'}</span>
                </button>
              </div>
            </form>
          </div>

          {/* Prediction Output Column (5 cols) */}
          <div className="lg:col-span-5 space-y-6">
            {predictionResult ? (
              <div className="space-y-6 animate-in zoom-in-95 duration-200">
                {/* Result Card */}
                <div className="p-6 rounded-3xl bg-gradient-to-br from-rose-950/40 via-slate-900 to-slate-950 border border-rose-500/30 shadow-2xl space-y-5">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold uppercase tracking-widest text-rose-400">
                      Inference Outcome
                    </span>
                    <span className="px-2.5 py-0.5 rounded-full bg-rose-500/20 text-rose-300 font-mono text-xs">
                      Live Model Result
                    </span>
                  </div>

                  {/* Binary Classification Result */}
                  <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-2">
                    <div className="text-xs font-semibold text-slate-400 uppercase">
                      Binary Logistic Regression
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <span className="text-2xl">
                          {predictionResult.binary_prediction.prediction === 'GOOD' ? '🍷' : '📉'}
                        </span>
                        <div>
                          <div className={`text-2xl font-black tracking-tight ${
                            predictionResult.binary_prediction.prediction === 'GOOD' ? 'text-emerald-400' : 'text-rose-400'
                          }`}>
                            {predictionResult.binary_prediction.prediction} WINE
                          </div>
                          <div className="text-xs text-slate-400">
                            Threshold: Quality ≥ {predictionResult.binary_prediction.threshold}
                          </div>
                        </div>
                      </div>

                      <div className="text-right">
                        <div className="text-xl font-extrabold font-mono text-slate-100">
                          {predictionResult.binary_prediction.confidence_percent}%
                        </div>
                        <div className="text-[10px] text-slate-400 uppercase">Confidence</div>
                      </div>
                    </div>
                  </div>

                  {/* Multi-Class Classification Result */}
                  <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-3">
                    <div className="text-xs font-semibold text-slate-400 uppercase">
                      Multinomial Logistic Regression
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="text-xs text-slate-400">Predicted Quality Score:</div>
                        <div className="text-4xl font-black text-amber-400 font-mono">
                          {predictionResult.multiclass_prediction.predicted_quality}
                        </div>
                      </div>

                      <div className="text-right">
                        <div className="text-lg font-bold font-mono text-emerald-400">
                          {predictionResult.multiclass_prediction.highest_probability}%
                        </div>
                        <div className="text-[10px] text-slate-400">Peak Probability</div>
                      </div>
                    </div>

                    {/* Class Probability Distribution Bars */}
                    <div className="space-y-2 pt-2 border-t border-slate-800">
                      <div className="text-xs font-semibold text-slate-300">
                        Class Probability Distribution:
                      </div>

                      <div className="space-y-2">
                        {predictionResult.multiclass_prediction.class_probabilities.map((item) => {
                          const isPredicted = String(item.quality) === String(predictionResult.multiclass_prediction.predicted_quality);

                          return (
                            <div key={item.quality} className="space-y-1 text-xs">
                              <div className="flex justify-between font-mono">
                                <span className={isPredicted ? 'text-amber-300 font-bold' : 'text-slate-400'}>
                                  Quality {item.quality} {isPredicted && '★'}
                                </span>
                                <span className={isPredicted ? 'text-amber-300 font-bold' : 'text-slate-400'}>
                                  {item.percent}%
                                </span>
                              </div>

                              <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden">
                                <div
                                  className={`h-full rounded-full transition-all duration-500 ${
                                    isPredicted
                                      ? 'bg-gradient-to-r from-amber-500 to-rose-500'
                                      : 'bg-slate-600'
                                  }`}
                                  style={{ width: `${Math.max(item.percent, 2)}%` }}
                                />
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="h-full flex flex-col items-center justify-center p-8 rounded-3xl bg-slate-900/30 border border-dashed border-slate-800 text-center space-y-3">
                <FlaskConical className="w-12 h-12 text-slate-600" />
                <h4 className="text-base font-bold text-slate-300">Awaiting Input</h4>
                <p className="text-xs text-slate-500 max-w-xs leading-relaxed">
                  Enter custom physicochemical values on the left or select a quick preset, then click "Predict Wine Quality".
                </p>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
