import React, { useState, useEffect } from 'react';
import {
  BarChart3,
  PieChart,
  Grid,
  Filter,
  AlertCircle
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid
} from 'recharts';
import { api } from '../api';
import CorrelationHeatmap from '../components/CorrelationHeatmap';

export default function VisualizationsPage({
  datasetSummary,
  isDark
}) {
  const [correlationData, setCorrelationData] = useState(null);
  const [distributionData, setDistributionData] = useState(null);
  const [selectedFeature, setSelectedFeature] = useState('');
  const [loading, setLoading] = useState(false);

  const hasData = datasetSummary && datasetSummary.status === 'loaded';

  useEffect(() => {
    if (hasData) {
      setLoading(true);
      Promise.all([api.getCorrelation(), api.getDistributions()])
        .then(([corr, dist]) => {
          setCorrelationData(corr);
          setDistributionData(dist);
          const feats = Object.keys(dist.features || {});
          if (feats.length > 0) {
            setSelectedFeature(feats[0]);
          }
        })
        .catch((err) => console.error('Visualization load error:', err))
        .finally(() => setLoading(false));
    }
  }, [hasData, datasetSummary]);

  const featureOptions = distributionData ? Object.keys(distributionData.features || {}) : [];
  const currentFeatureBins = distributionData?.features?.[selectedFeature] || [];

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-6 rounded-3xl bg-slate-900/60 border border-slate-800">
        <div className="space-y-1">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 rounded-xl bg-sky-500/15 text-sky-400 flex items-center justify-center">
              <BarChart3 className="w-4 h-4" />
            </div>
            <h3 className="text-lg font-bold text-slate-100">
              Exploratory Data Visualizations
            </h3>
          </div>
          <p className="text-xs text-slate-400">
            Interactive charts displaying quality class balance, feature histograms, and correlation heatmaps.
          </p>
        </div>
      </div>

      {!hasData ? (
        <div className="p-12 rounded-3xl border border-dashed border-slate-800 bg-slate-900/40 text-center space-y-3">
          <AlertCircle className="w-10 h-10 text-amber-400 mx-auto" />
          <h4 className="text-base font-bold text-slate-200">No Dataset Uploaded</h4>
          <p className="text-xs text-slate-400 max-w-sm mx-auto">
            Please upload a dataset or load the UCI sample to generate exploratory visualizations.
          </p>
        </div>
      ) : (
        <>
          {/* Top Row: Quality Distribution & Feature Histogram */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Chart 1: Wine Quality Target Distribution */}
            <div className="p-6 rounded-3xl bg-slate-900/60 border border-slate-800 shadow-md space-y-4">
              <div>
                <h4 className="text-sm font-bold text-slate-200 uppercase tracking-wider">
                  Wine Quality Score Distribution
                </h4>
                <p className="text-xs text-slate-400">
                  Target column frequency count (demonstrating class imbalance)
                </p>
              </div>

              <div className="h-64 w-full pt-2">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={distributionData?.target_distribution || []}>
                    <CartesianGrid strokeDasharray="3 3" stroke={isDark ? '#334155' : '#e2e8f0'} opacity={0.5} />
                    <XAxis dataKey="quality" stroke={isDark ? '#94a3b8' : '#64748b'} tick={{ fontSize: 11 }} label={{ value: 'Quality Score', position: 'insideBottom', offset: -5, fill: '#94a3b8', fontSize: 11 }} />
                    <YAxis stroke={isDark ? '#94a3b8' : '#64748b'} tick={{ fontSize: 11 }} label={{ value: 'Sample Count', angle: -90, position: 'insideLeft', offset: 15, fill: '#94a3b8', fontSize: 11 }} />
                    <Tooltip
                      content={({ active, payload }) => {
                        if (active && payload && payload.length) {
                          const d = payload[0].payload;
                          return (
                            <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-slate-100 font-mono shadow-lg">
                              <div className="font-bold text-rose-400">Quality Level: {d.quality}</div>
                              <div>Count: <span className="font-bold">{d.count} samples</span></div>
                            </div>
                          );
                        }
                        return null;
                      }}
                    />
                    <Bar dataKey="count" fill="#e11d48" radius={[6, 6, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Chart 2: Feature Histogram with Dropdown Selector */}
            <div className="p-6 rounded-3xl bg-slate-900/60 border border-slate-800 shadow-md space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <h4 className="text-sm font-bold text-slate-200 uppercase tracking-wider">
                    Feature Histogram Distribution
                  </h4>
                  <p className="text-xs text-slate-400">
                    Binned frequency distribution for chemical attributes
                  </p>
                </div>

                <div className="flex items-center space-x-2">
                  <Filter className="w-3.5 h-3.5 text-slate-400" />
                  <select
                    value={selectedFeature}
                    onChange={(e) => setSelectedFeature(e.target.value)}
                    className="px-3 py-1.5 rounded-xl bg-slate-800 border border-slate-700 text-xs text-slate-200 font-medium focus:outline-none focus:border-rose-500"
                  >
                    {featureOptions.map((feat) => (
                      <option key={feat} value={feat}>
                        {feat}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="h-64 w-full pt-2">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={currentFeatureBins}>
                    <CartesianGrid strokeDasharray="3 3" stroke={isDark ? '#334155' : '#e2e8f0'} opacity={0.5} />
                    <XAxis dataKey="bin" stroke={isDark ? '#94a3b8' : '#64748b'} tick={{ fontSize: 9 }} interval={0} angle={-25} textAnchor="end" height={45} />
                    <YAxis stroke={isDark ? '#94a3b8' : '#64748b'} tick={{ fontSize: 11 }} />
                    <Tooltip
                      content={({ active, payload }) => {
                        if (active && payload && payload.length) {
                          const d = payload[0].payload;
                          return (
                            <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-slate-100 font-mono shadow-lg">
                              <div className="font-bold text-sky-400">Interval: {d.bin}</div>
                              <div>Count: <span className="font-bold">{d.count}</span></div>
                            </div>
                          );
                        }
                        return null;
                      }}
                    />
                    <Bar dataKey="count" fill="#0ea5e9" radius={[6, 6, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>

          {/* Bottom Row: Correlation Heatmap */}
          <div className="p-6 rounded-3xl bg-slate-900/60 border border-slate-800 shadow-md">
            <CorrelationHeatmap
              correlationData={correlationData}
              isDark={isDark}
            />
          </div>
        </>
      )}
    </div>
  );
}
