import React from 'react';
import {
  GraduationCap,
  Users,
  UserCheck,
  BookOpen,
  HelpCircle,
  Award,
  Layers,
  Binary,
  Scale,
  Sparkles
} from 'lucide-react';

export default function AboutPage() {
  const vivaFaqs = [
    {
      q: 'Why did you choose Logistic Regression instead of Linear Regression?',
      a: 'Linear Regression predicts unbounded continuous values (-∞ to +∞), which could produce invalid probabilities < 0 or > 1. Logistic Regression applies the sigmoid (or softmax) function, mapping linear outputs into a valid probability range [0, 1].'
    },
    {
      q: 'What is the mathematical difference between Binary and Multinomial Logistic Regression?',
      a: 'Binary Logistic Regression uses the Sigmoid function σ(z) = 1 / (1 + e^-z) with Binary Cross-Entropy loss for K=2 classes. Multinomial Logistic Regression generalizes this via the Softmax activation P(y=k|x) = e^(w_k · x) / ∑ e^(w_j · x) with Categorical Cross-Entropy across all K > 2 classes simultaneously.'
    },
    {
      q: 'Why is StandardScaler necessary for Logistic Regression?',
      a: 'Features like "total sulfur dioxide" have values up to 280, while "chlorides" are around 0.08. Logistic Regression uses gradient-based optimization (L-BFGS). Without scaling, features with large magnitudes dominate the loss gradients and delay convergence.'
    },
    {
      q: 'What is the significance of the ROC-AUC score?',
      a: 'ROC-AUC measures the model\'s discriminatory ability across all classification thresholds, independent of class imbalance. An AUC of 1.0 means perfect separation between Poor and Good wines, while 0.5 represents a random guess.'
    },
    {
      q: 'Why does Binary Classification often achieve higher accuracy than Multinomial?',
      a: 'Binary classification groups multi-class grades into two categories (e.g. < 6 vs ≥ 6), eliminating misclassifications between adjacent quality scores (like misclassifying a quality 5 as 6). Multinomial classification solves the much harder task of exact multi-class discrimination.'
    }
  ];

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      {/* Hero Banner */}
      <div className="p-8 rounded-3xl bg-gradient-to-br from-rose-950/40 via-slate-900 to-slate-950 border border-rose-500/20 shadow-2xl space-y-4">
        <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-rose-500/15 border border-rose-500/30 text-rose-400 text-xs font-semibold uppercase tracking-wider">
          <span>Academic Project Portfolio</span>
        </div>

        <h2 className="text-3xl font-extrabold text-slate-100 tracking-tight">
          Wine Quality Classification Using Logistic Regression and Multinomial Logistic Regression
        </h2>
        <p className="text-sm text-slate-300 max-w-3xl leading-relaxed">
          A comprehensive machine learning research and demonstration project developed for the Bachelor of Technology curriculum in Machine Learning.
        </p>

        <div className="pt-2 grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
          <div className="p-3 rounded-2xl bg-slate-900/80 border border-slate-800">
            <span className="text-slate-500 block">Course</span>
            <span className="font-bold text-slate-200">Machine Learning</span>
          </div>
          <div className="p-3 rounded-2xl bg-slate-900/80 border border-slate-800">
            <span className="text-slate-500 block">Degree</span>
            <span className="font-bold text-slate-200">Bachelor of Technology (B.Tech)</span>
          </div>
          <div className="p-3 rounded-2xl bg-slate-900/80 border border-slate-800">
            <span className="text-slate-500 block">Academic Year</span>
            <span className="font-bold text-rose-400 font-mono">2026-27</span>
          </div>
          <div className="p-3 rounded-2xl bg-slate-900/80 border border-slate-800">
            <span className="text-slate-500 block">Department</span>
            <span className="font-bold text-slate-200">CSIT</span>
          </div>
        </div>
      </div>

      {/* Project Team & Guide */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Students Card */}
        <div className="p-6 rounded-3xl bg-slate-900/60 border border-slate-800 space-y-4">
          <div className="flex items-center space-x-3 text-rose-400">
            <Users className="w-5 h-5" />
            <h4 className="text-base font-bold text-slate-100">Project Students</h4>
          </div>

          <div className="space-y-3">
            <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 flex items-center justify-between">
              <div>
                <div className="text-sm font-bold text-slate-100">S. Venugopal</div>
                <div className="text-xs text-slate-400">B.Tech Student (CSIT)</div>
              </div>
              <span className="font-mono text-xs px-2.5 py-1 rounded-lg bg-rose-500/10 text-rose-400 border border-rose-500/20 font-bold">
                Roll No: 2520090185
              </span>
            </div>

            <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 flex items-center justify-between">
              <div>
                <div className="text-sm font-bold text-slate-100">Shashank Bangale</div>
                <div className="text-xs text-slate-400">B.Tech Student (CSIT)</div>
              </div>
              <span className="font-mono text-xs px-2.5 py-1 rounded-lg bg-rose-500/10 text-rose-400 border border-rose-500/20 font-bold">
                Roll No: 2520090086
              </span>
            </div>
          </div>
        </div>

        {/* Project Guide Card */}
        <div className="p-6 rounded-3xl bg-slate-900/60 border border-slate-800 space-y-4">
          <div className="flex items-center space-x-3 text-emerald-400">
            <UserCheck className="w-5 h-5" />
            <h4 className="text-base font-bold text-slate-100">Project Guide & Supervisor</h4>
          </div>

          <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-2">
            <div className="flex items-center justify-between">
              <div className="text-base font-bold text-slate-100">
                I V Sai Lakshmi Haritha
              </div>
              <span className="text-xs px-2.5 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 font-semibold">
                Assistant Professor
              </span>
            </div>
            <p className="text-xs text-slate-300">
              Department of Computer Science and Information Technology (CSIT)
            </p>
            <p className="text-[11px] text-slate-400 pt-1 leading-relaxed">
              Guided algorithm modeling, theoretical foundations, data preprocessing verification, and performance benchmarking.
            </p>
          </div>
        </div>
      </div>

      {/* Machine Learning Concepts Explained */}
      <div className="space-y-4">
        <div className="flex items-center space-x-2 text-rose-400">
          <BookOpen className="w-5 h-5" />
          <h4 className="text-base font-bold text-slate-100 uppercase tracking-wider">
            Machine Learning Theoretical Foundations
          </h4>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-5 rounded-3xl bg-slate-900/60 border border-slate-800 space-y-2.5">
            <div className="w-9 h-9 rounded-xl bg-rose-500/15 text-rose-400 flex items-center justify-center">
              <Binary className="w-4 h-4" />
            </div>
            <h5 className="text-sm font-bold text-slate-100">Logistic Regression</h5>
            <p className="text-xs text-slate-400 leading-relaxed">
              Logistic Regression is a supervised machine learning algorithm used for classification. In this project, it is used to classify wine into two categories: <strong>Good</strong> (quality ≥ threshold) and <strong>Poor</strong> (quality &lt; threshold).
            </p>
            <div className="p-2.5 rounded-xl bg-slate-950 font-mono text-[11px] text-rose-300">
              P(y=1|x) = 1 / (1 + e^-z)
            </div>
          </div>

          <div className="p-5 rounded-3xl bg-slate-900/60 border border-slate-800 space-y-2.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-500/15 text-emerald-400 flex items-center justify-center">
              <Layers className="w-4 h-4" />
            </div>
            <h5 className="text-sm font-bold text-slate-100">Multinomial Logistic Regression</h5>
            <p className="text-xs text-slate-400 leading-relaxed">
              Multinomial Logistic Regression is an extension of Logistic Regression that can classify data into more than two classes. In this project, it predicts different wine quality scores (e.g., 3, 4, 5, 6, 7, 8).
            </p>
            <div className="p-2.5 rounded-xl bg-slate-950 font-mono text-[11px] text-emerald-300">
              P(y=k|x) = e^(w_k · x) / ∑ e^(w_j · x)
            </div>
          </div>

          <div className="p-5 rounded-3xl bg-slate-900/60 border border-slate-800 space-y-2.5">
            <div className="w-9 h-9 rounded-xl bg-sky-500/15 text-sky-400 flex items-center justify-center">
              <Scale className="w-4 h-4" />
            </div>
            <h5 className="text-sm font-bold text-slate-100">StandardScaler</h5>
            <p className="text-xs text-slate-400 leading-relaxed">
              StandardScaler converts numerical features to a common scale so that features with large numerical values do not dominate the model during optimization.
            </p>
            <div className="p-2.5 rounded-xl bg-slate-950 font-mono text-[11px] text-sky-300">
              z = (x - μ) / σ
            </div>
          </div>
        </div>
      </div>

      {/* Viva Defense Guide & FAQs */}
      <div className="p-6 rounded-3xl bg-slate-900/60 border border-slate-800 space-y-4">
        <div className="flex items-center space-x-2 text-amber-400">
          <HelpCircle className="w-5 h-5" />
          <h4 className="text-base font-bold text-slate-100">
            Project Viva & Defense Examination Cheat-Sheet
          </h4>
        </div>
        <p className="text-xs text-slate-400">
          Core technical questions typically asked by external examiners during B.Tech project presentations.
        </p>

        <div className="space-y-3">
          {vivaFaqs.map((faq, idx) => (
            <div key={idx} className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-1.5">
              <div className="text-xs font-bold text-rose-400 flex items-start gap-2">
                <span className="font-mono">Q{idx + 1}:</span>
                <span>{faq.q}</span>
              </div>
              <div className="text-xs text-slate-300 pl-6 leading-relaxed">
                {faq.a}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
