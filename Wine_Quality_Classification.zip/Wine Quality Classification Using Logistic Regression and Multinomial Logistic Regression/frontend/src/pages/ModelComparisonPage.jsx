import React from 'react';
import {
  GitCompare,
  Trophy,
  BarChart2,
  Download,
  CheckCircle2,
  HelpCircle,
  AlertCircle
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  CartesianGrid
} from 'recharts';
import { api } from '../api';

export default function ModelComparisonPage({
  comparisonData,
  isTrained,
  isDark
}) {
  const comp = comparisonData;

  const chartData = comp?.comparison_table?.map((row) => ({
    metric: row.metric,
    'Logistic Regression (Binary)': Number((row.logistic_regression * 100).toFixed(2)),
    'Multinomial Logistic (Multi-Class)': Number((row.multinomial_regression * 100).toFixed(2)),
  })) || [];

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      {/* Header & Export Action */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-6 rounded-3xl bg-slate-900/60 border border-slate-800">
        <div className="space-y-1">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 rounded-xl bg-purple-500/15 text-purple-400 flex items-center justify-center">
              <GitCompare className="w-4 h-4" />
            </div>
            <h3 className="text-lg font-bold text-slate-100">Model Performance Comparison</h3>
          </div>
          <p className="text-xs text-slate-400">
            Comparative evaluation between Binary Logistic Regression and Multinomial Logistic Regression.
          </p>
        </div>

        {isTrained && (
          <a
            href={api.getDownloadReportUrl()}
            download
            className="flex items-center space-x-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-bold shadow-md shadow-emerald-600/25 transition-all"
          >
            <Download className="w-4 h-4" />
            <span>Download Project Evaluation Report</span>
          </a>
        )}
      </div>

      {!isTrained || !comp || comp.status === 'not_trained' ? (
        <div className="p-12 rounded-3xl border border-dashed border-slate-800 bg-slate-900/40 text-center space-y-3">
          <AlertCircle className="w-10 h-10 text-amber-400 mx-auto" />
          <h4 className="text-base font-bold text-slate-200">No Models Trained Yet</h4>
          <p className="text-xs text-slate-400 max-w-sm mx-auto">
            Please train the models first to generate the comparative performance charts and metrics.
          </p>
        </div>
      ) : (
        <>
          {/* Best Performing Model Card */}
          <div className="p-6 rounded-3xl bg-gradient-to-br from-purple-950/40 via-slate-900 to-slate-950 border border-purple-500/30 shadow-xl space-y-3">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-300 flex items-center justify-center text-xl">
                <Trophy className="w-5 h-5 text-amber-400" />
              </div>
              <div>
                <span className="text-[11px] font-bold uppercase tracking-wider text-amber-400">
                  Model Evaluation Verdict
                </span>
                <h4 className="text-lg font-extrabold text-slate-100">
                  Best Performing Model: <span className="text-rose-400">{comp.best_model}</span>
                </h4>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 text-xs text-slate-300 leading-relaxed font-sans">
              {comp.conclusion}
            </div>
          </div>

          {/* Side-by-side Table & Bar Chart */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Comparison Table */}
            <div className="p-6 rounded-3xl bg-slate-900/60 border border-slate-800 shadow-md space-y-4">
              <div>
                <h4 className="text-sm font-bold text-slate-200 uppercase tracking-wider">
                  Side-By-Side Metrics Comparison Table
                </h4>
                <p className="text-xs text-slate-400">
                  Actual evaluated values on the independent 20% test dataset
                </p>
              </div>

              <div className="overflow-x-auto rounded-2xl border border-slate-800 bg-slate-900/40">
                <table className="w-full text-xs text-left border-collapse">
                  <thead className="bg-slate-800/70 text-slate-300 text-[11px] uppercase font-mono tracking-wider border-b border-slate-800">
                    <tr>
                      <th className="p-3.5">Evaluation Metric</th>
                      <th className="p-3.5 text-right text-rose-400">Logistic Regression</th>
                      <th className="p-3.5 text-right text-emerald-400">Multinomial Regression</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60 font-mono">
                    {comp.comparison_table?.map((row) => (
                      <tr key={row.metric} className="hover:bg-slate-800/30">
                        <td className="p-3.5 font-semibold text-slate-200">{row.metric}</td>
                        <td className="p-3.5 text-right font-bold text-rose-300">
                          {row.metric === 'F1 Score'
                            ? row.logistic_regression.toFixed(4)
                            : `${(row.logistic_regression * 100).toFixed(2)}%`}
                        </td>
                        <td className="p-3.5 text-right font-bold text-emerald-300">
                          {row.metric === 'F1 Score'
                            ? row.multinomial_regression.toFixed(4)
                            : `${(row.multinomial_regression * 100).toFixed(2)}%`}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="text-[11px] text-slate-400 italic">
                * Logistic Regression measures binary distinction (Poor vs Good), while Multinomial measures multi-class resolution across all classes.
              </div>
            </div>

            {/* Comparative Bar Chart */}
            <div className="p-6 rounded-3xl bg-slate-900/60 border border-slate-800 shadow-md space-y-4">
              <div>
                <h4 className="text-sm font-bold text-slate-200 uppercase tracking-wider">
                  Comparative Performance Chart (%)
                </h4>
                <p className="text-xs text-slate-400">
                  Visual benchmark across Accuracy, Precision, Recall, and F1 Score (scaled to %)
                </p>
              </div>

              <div className="h-72 w-full pt-2">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={chartData} margin={{ top: 20, right: 20, left: -10, bottom: 10 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke={isDark ? '#334155' : '#e2e8f0'} opacity={0.5} />
                    <XAxis dataKey="metric" stroke={isDark ? '#94a3b8' : '#64748b'} tick={{ fontSize: 11 }} />
                    <YAxis domain={[0, 100]} stroke={isDark ? '#94a3b8' : '#64748b'} tick={{ fontSize: 11 }} unit="%" />
                    <Tooltip
                      content={({ active, payload, label }) => {
                        if (active && payload && payload.length) {
                          return (
                            <div className="p-3 rounded-xl bg-slate-900 border border-slate-700 text-slate-100 shadow-xl text-xs space-y-1 font-mono">
                              <div className="font-bold text-slate-300 mb-1">{label}</div>
                              {payload.map((entry, index) => (
                                <div key={index} className="flex justify-between gap-4" style={{ color: entry.color }}>
                                  <span>{entry.name}:</span>
                                  <span className="font-bold">{entry.value}%</span>
                                </div>
                              ))}
                            </div>
                          );
                        }
                        return null;
                      }}
                    />
                    <Legend wrapperStyle={{ fontSize: 12, paddingTop: 10 }} />
                    <Bar dataKey="Logistic Regression (Binary)" fill="#e11d48" radius={[6, 6, 0, 0]} />
                    <Bar dataKey="Multinomial Logistic (Multi-Class)" fill="#10b981" radius={[6, 6, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
