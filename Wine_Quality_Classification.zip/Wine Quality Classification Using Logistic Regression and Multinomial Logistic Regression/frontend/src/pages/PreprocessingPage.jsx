import React from 'react';
import {
  Sliders,
  CheckCircle2,
  GitFork,
  Scale,
  Copy,
  Binary,
  Layers,
  Download,
  AlertCircle,
  Play
} from 'lucide-react';
import { api } from '../api';

export default function PreprocessingPage({
  preprocessingData,
  datasetSummary,
  onTrain,
  isTraining,
  isDark
}) {
  const prep = preprocessingData;
  const hasData = datasetSummary && datasetSummary.status === 'loaded';

  const steps = [
    {
      step: '1',
      title: 'Missing Values Imputation',
      desc: 'Check each column for null or missing values. Numerical columns are filled with median; categorical columns with mode.',
      status: prep?.missing_imputed ? (Object.keys(prep.missing_imputed).length > 0 ? `${Object.keys(prep.missing_imputed).length} Imputed` : '0 Missing Values') : 'Ready',
      icon: CheckCircle2,
      badge: 'Step 1'
    },
    {
      step: '2',
      title: 'Duplicate Rows Handling',
      desc: 'Identify and remove redundant identical observations to prevent model overfitting.',
      status: prep?.duplicates_removed !== undefined ? `${prep.duplicates_removed} Duplicates Removed` : 'Ready',
      icon: Copy,
      badge: 'Step 2'
    },
    {
      step: '3',
      title: 'Feature & Target Separation',
      desc: 'Split dataset into predictor feature matrix X and target label vector y (quality).',
      status: prep?.num_features ? `${prep.num_features} Features Separated` : 'Ready',
      icon: GitFork,
      badge: 'Step 3'
    },
    {
      step: '4',
      title: 'Categorical Feature Encoding',
      desc: 'Detect object or categorical features and apply One-Hot Encoding (OHE) dummy variables if required.',
      status: prep?.categorical_encoded ? (prep.categorical_encoded.length > 0 ? `${prep.categorical_encoded.length} Encoded` : 'All Features Numeric') : 'Ready',
      icon: Binary,
      badge: 'Step 4'
    },
    {
      step: '5',
      title: '80 / 20 Train-Test Split',
      desc: 'Partition dataset into 80% training set and 20% independent test set with fixed random_state=42 for reproducibility.',
      status: prep?.train_samples ? `${prep.train_samples} Train / ${prep.test_samples} Test` : '80% / 20% Split',
      icon: Layers,
      badge: 'Step 5'
    },
    {
      step: '6',
      title: 'StandardScaler Feature Normalization',
      desc: 'Normalize numerical predictors to have zero mean (μ = 0) and unit variance (σ = 1) using StandardScaler.',
      status: prep?.scaling_params ? 'Z-score Normalized' : 'Ready',
      icon: Scale,
      badge: 'Step 6'
    }
  ];

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      {/* Header & Export Action */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h3 className="text-xl font-bold text-slate-100">Automated Preprocessing Pipeline</h3>
          <p className="text-xs text-slate-400">
            6-Step rigorous scientific data preparation ensures unbiased Logistic Regression convergence.
          </p>
        </div>

        {hasData && (
          <div className="flex items-center gap-3">
            <a
              href={api.getDownloadProcessedUrl()}
              download
              className="flex items-center space-x-2 px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold transition-all"
            >
              <Download className="w-4 h-4 text-emerald-400" />
              <span>Download Preprocessed CSV</span>
            </a>

            <button
              onClick={onTrain}
              disabled={isTraining}
              className="flex items-center space-x-2 px-5 py-2 rounded-xl bg-gradient-to-r from-rose-600 to-pink-600 hover:from-rose-500 hover:to-pink-500 text-white text-xs font-bold shadow-md shadow-rose-600/30 transition-all"
            >
              <Play className="w-4 h-4 fill-white" />
              <span>Train Models</span>
            </button>
          </div>
        )}
      </div>

      {!hasData ? (
        <div className="p-12 rounded-3xl border border-dashed border-slate-800 bg-slate-900/40 text-center space-y-3">
          <AlertCircle className="w-10 h-10 text-amber-400 mx-auto" />
          <h4 className="text-base font-bold text-slate-200">No Dataset Uploaded</h4>
          <p className="text-xs text-slate-400 max-w-sm mx-auto">
            Please upload a wine dataset from the Dataset tab to view the automated preprocessing pipeline.
          </p>
        </div>
      ) : (
        <>
          {/* Before & After Stat Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-1">
              <span className="text-[11px] font-semibold text-slate-400 uppercase">
                Rows Before Preprocessing
              </span>
              <div className="text-2xl font-extrabold font-mono text-slate-100">
                {prep?.rows_before ? prep.rows_before.toLocaleString() : datasetSummary.rows.toLocaleString()}
              </div>
              <p className="text-[11px] text-slate-500">Raw initial file records</p>
            </div>

            <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-1">
              <span className="text-[11px] font-semibold text-rose-400 uppercase">
                Duplicate Rows Removed
              </span>
              <div className="text-2xl font-extrabold font-mono text-rose-300">
                {prep?.duplicates_removed !== undefined ? prep.duplicates_removed : datasetSummary.duplicates_count}
              </div>
              <p className="text-[11px] text-slate-500">Exact duplicate observations</p>
            </div>

            <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-1">
              <span className="text-[11px] font-semibold text-emerald-400 uppercase">
                Rows After Preprocessing
              </span>
              <div className="text-2xl font-extrabold font-mono text-emerald-300">
                {prep?.rows_after ? prep.rows_after.toLocaleString() : (datasetSummary.rows - datasetSummary.duplicates_count).toLocaleString()}
              </div>
              <p className="text-[11px] text-slate-500">Cleaned dataset for modeling</p>
            </div>

            <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-1">
              <span className="text-[11px] font-semibold text-sky-400 uppercase">
                Train / Test Partition
              </span>
              <div className="text-2xl font-extrabold font-mono text-sky-300">
                80% / 20%
              </div>
              <p className="text-[11px] text-slate-500">
                {prep?.train_samples ? `${prep.train_samples} train / ${prep.test_samples} test` : 'Random state 42'}
              </p>
            </div>
          </div>

          {/* 6-Step Visual Cards */}
          <div className="space-y-4">
            <h4 className="text-sm font-bold text-slate-300 uppercase tracking-wider">
              Executed Preprocessing Steps
            </h4>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {steps.map((s) => {
                const Icon = s.icon;
                return (
                  <div
                    key={s.step}
                    className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800/80 hover:border-slate-700 transition-all space-y-3 relative group"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-rose-500/15 text-rose-400 border border-rose-500/30 uppercase">
                        {s.badge}
                      </span>
                      <Icon className="w-5 h-5 text-emerald-400" />
                    </div>

                    <div>
                      <h5 className="text-sm font-bold text-slate-100">{s.title}</h5>
                      <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                        {s.desc}
                      </p>
                    </div>

                    <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-xs">
                      <span className="text-slate-500">Outcome:</span>
                      <span className="font-semibold text-emerald-400 font-mono">
                        {s.status}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* StandardScaler Parameters Table */}
          {prep?.scaling_params && (
            <div className="space-y-3 pt-2">
              <div>
                <h4 className="text-sm font-bold text-slate-200 uppercase tracking-wider">
                  StandardScaler Parameters (μ and σ)
                </h4>
                <p className="text-xs text-slate-400">
                  Feature standardization formula: <code className="text-rose-400 font-mono">z = (x - μ) / σ</code>
                </p>
              </div>

              <div className="overflow-x-auto rounded-2xl border border-slate-800 bg-slate-900/40">
                <table className="w-full text-xs text-left border-collapse">
                  <thead className="bg-slate-800/70 text-slate-300 text-[11px] uppercase font-mono tracking-wider border-b border-slate-800">
                    <tr>
                      <th className="p-3">Feature Name</th>
                      <th className="p-3">Fitted Mean (μ)</th>
                      <th className="p-3">Fitted Std Deviation (σ)</th>
                      <th className="p-3">Scaled Range Target</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {Object.entries(prep.scaling_params).map(([feat, params]) => (
                      <tr key={feat} className="hover:bg-slate-800/30">
                        <td className="p-3 font-semibold text-slate-200 font-mono">{feat}</td>
                        <td className="p-3 font-mono text-slate-300">{params.mean}</td>
                        <td className="p-3 font-mono text-slate-300">{params.std}</td>
                        <td className="p-3 font-mono text-emerald-400">Mean = 0, Std = 1</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}
