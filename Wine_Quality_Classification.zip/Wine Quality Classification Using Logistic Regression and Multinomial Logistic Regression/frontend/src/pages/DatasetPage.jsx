import React, { useState, useRef } from 'react';
import {
  UploadCloud,
  FileSpreadsheet,
  Trash2,
  Play,
  CheckCircle2,
  AlertTriangle,
  FileText,
  Table,
  Eye,
  Search,
  ChevronLeft,
  ChevronRight,
  X,
  Sparkles
} from 'lucide-react';
import { api } from '../api';

export default function DatasetPage({
  datasetSummary,
  onUploadSuccess,
  onRemoveDataset,
  onTrain,
  isTraining,
  setActiveTab,
  isDark
}) {
  const [dragActive, setDragActive] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [fullModalOpen, setFullModalOpen] = useState(false);
  
  // Full Dataset Modal state
  const [modalPage, setModalPage] = useState(1);
  const [modalSearch, setModalSearch] = useState('');
  const [modalData, setModalData] = useState({ rows: [], total: 0, total_pages: 1 });
  const [loadingModalData, setLoadingModalData] = useState(false);

  const fileInputRef = useRef(null);

  const handleDrag = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = async (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      await processUpload(e.dataTransfer.files[0]);
    }
  };

  const handleFileChange = async (e) => {
    if (e.target.files && e.target.files[0]) {
      await processUpload(e.target.files[0]);
    }
  };

  const processUpload = async (file) => {
    setErrorMessage('');
    setUploading(true);
    try {
      const summary = await api.uploadDataset(file);
      onUploadSuccess(summary);
    } catch (err) {
      setErrorMessage(
        err.response?.data?.detail || 'Failed to upload dataset. Please ensure it is a valid CSV or Excel file.'
      );
    } finally {
      setUploading(false);
    }
  };

  const handleTargetChange = async (e) => {
    const selected = e.target.value;
    try {
      const updated = await api.selectTarget(selected);
      onUploadSuccess(updated);
    } catch (err) {
      setErrorMessage('Failed to update target column.');
    }
  };

  const openFullModal = async () => {
    setFullModalOpen(true);
    fetchModalPage(1, modalSearch);
  };

  const fetchModalPage = async (page, search) => {
    setLoadingModalData(true);
    try {
      const res = await api.getDatasetPreview(page, 20, search);
      setModalData(res);
      setModalPage(page);
    } catch (err) {
      console.error(err);
    } finally {
      setLoadingModalData(false);
    }
  };

  const hasData = datasetSummary && datasetSummary.status === 'loaded';

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      {/* Upload Zone */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-bold text-slate-100">Upload Wine Quality Dataset</h3>
            <p className="text-xs text-slate-400">
              Drag and drop your file or select from computer. Supports CSV, XLS, and XLSX.
            </p>
          </div>
          <div className="flex items-center space-x-2">
            <span className="text-[11px] font-mono px-2.5 py-1 rounded-lg bg-slate-800 text-slate-300 border border-slate-700">
              Supported: .csv, .xlsx, .xls
            </span>
          </div>
        </div>

        {errorMessage && (
          <div className="p-4 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 flex-shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        <div
          onDragEnter={handleDrag}
          onDragOver={handleDrag}
          onDragLeave={handleDrag}
          onDrop={handleDrop}
          onClick={() => fileInputRef.current?.click()}
          className={`relative p-8 sm:p-12 rounded-3xl border-2 border-dashed transition-all duration-200 cursor-pointer text-center group ${
            dragActive
              ? 'border-rose-500 bg-rose-500/10 scale-[0.99]'
              : 'border-slate-800 hover:border-rose-500/40 bg-slate-900/40 hover:bg-slate-900/60'
          }`}
        >
          <input
            ref={fileInputRef}
            type="file"
            accept=".csv, .xlsx, .xls"
            onChange={handleFileChange}
            className="hidden"
          />

          <div className="space-y-3 max-w-sm mx-auto">
            <div className="w-16 h-16 mx-auto rounded-2xl bg-rose-500/10 border border-rose-500/20 group-hover:bg-rose-500/20 flex items-center justify-center transition-transform group-hover:scale-110 duration-200">
              {uploading ? (
                <div className="w-6 h-6 border-2 border-rose-500 border-t-transparent rounded-full animate-spin" />
              ) : (
                <UploadCloud className="w-8 h-8 text-rose-400" />
              )}
            </div>

            <div className="space-y-1">
              <p className="text-base font-bold text-slate-200">
                {uploading ? 'Processing Dataset...' : 'Upload Wine Quality Dataset'}
              </p>
              <p className="text-xs text-slate-400">
                Drag and drop your file here, or <span className="text-rose-400 underline font-medium">browse files</span>
              </p>
            </div>

            <div className="pt-2 flex justify-center gap-2">
              <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-400">CSV</span>
              <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-400">XLSX</span>
              <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-400">XLS</span>
            </div>
          </div>
        </div>
      </div>

      {/* Dataset Summary & Actions */}
      {hasData && (
        <div className="space-y-6">
          {/* File Card & Main Actions */}
          <div className="p-6 rounded-3xl bg-slate-900/60 border border-slate-800/80 shadow-md flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 rounded-2xl bg-emerald-500/15 text-emerald-400 flex items-center justify-center">
                <FileSpreadsheet className="w-6 h-6" />
              </div>
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <h4 className="text-base font-bold text-slate-100">{datasetSummary.filename}</h4>
                  <span className="px-2 py-0.5 text-[10px] font-bold rounded-full bg-emerald-500/15 text-emerald-400">
                    Uploaded Successfully
                  </span>
                </div>
                <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-400">
                  <span>Size: {(datasetSummary.file_size / 1024).toFixed(1)} KB</span>
                  <span>•</span>
                  <span>{datasetSummary.rows.toLocaleString()} Rows</span>
                  <span>•</span>
                  <span>{datasetSummary.columns} Columns</span>
                  <span>•</span>
                  <span>{datasetSummary.num_classes} Quality Classes</span>
                </div>
              </div>
            </div>

            {/* Buttons */}
            <div className="flex flex-wrap items-center gap-2.5">
              <button
                onClick={openFullModal}
                className="flex items-center space-x-1.5 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold transition-all"
              >
                <Eye className="w-4 h-4 text-sky-400" />
                <span>View Full Dataset</span>
              </button>

              <button
                onClick={() => {
                  if (fileInputRef.current) fileInputRef.current.value = '';
                  onRemoveDataset();
                }}
                className="flex items-center space-x-1.5 px-3.5 py-2.5 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/20 text-xs font-semibold transition-all"
              >
                <Trash2 className="w-4 h-4" />
                <span>Remove</span>
              </button>

              <button
                onClick={onTrain}
                disabled={isTraining}
                className="flex items-center space-x-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-rose-600 to-pink-600 hover:from-rose-500 hover:to-pink-500 text-white text-xs font-bold shadow-md shadow-rose-600/30 transition-all"
              >
                <Play className="w-4 h-4 fill-white" />
                <span>Start Machine Learning Analysis</span>
              </button>
            </div>
          </div>

          {/* Target Column Alert / Manual Selection */}
          {!datasetSummary.target_found ? (
            <div className="p-5 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-300 space-y-3">
              <div className="flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 flex-shrink-0" />
                <span className="font-bold text-sm">
                  Quality target column was not found. Please select the target column manually:
                </span>
              </div>
              <div className="flex items-center gap-3">
                <select
                  onChange={handleTargetChange}
                  value={datasetSummary.target_column || ''}
                  className="px-4 py-2 rounded-xl bg-slate-900 border border-amber-500/40 text-slate-100 text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-amber-500"
                >
                  <option value="">-- Choose Target Column --</option>
                  {datasetSummary.column_info?.map((col) => (
                    <option key={col.name} value={col.name}>
                      {col.name} ({col.dtype})
                    </option>
                  ))}
                </select>
                <span className="text-xs text-slate-400">
                  Selected target column will be predicted by the ML models.
                </span>
              </div>
            </div>
          ) : (
            <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800/80 flex flex-wrap items-center justify-between gap-4 text-xs">
              <div className="flex items-center space-x-2 text-slate-300">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>
                  Automatically detected target column:{' '}
                  <strong className="text-rose-400 font-mono text-sm">{datasetSummary.target_column}</strong>
                </span>
              </div>
              <div className="flex items-center gap-2 text-slate-400">
                <span>Unique Classes:</span>
                {datasetSummary.classes?.map((cls) => (
                  <span
                    key={cls}
                    className="px-2 py-0.5 rounded-md bg-rose-500/15 text-rose-300 font-mono font-bold"
                  >
                    {cls}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Dataset Preview (First 10 Rows) */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-sm font-bold text-slate-200 uppercase tracking-wider">
                  Dataset Preview (First 10 Rows)
                </h4>
                <p className="text-xs text-slate-400">
                  Initial rows sampled from the uploaded file
                </p>
              </div>
              <button
                onClick={openFullModal}
                className="text-xs text-rose-400 hover:text-rose-300 font-semibold underline"
              >
                View full dataset ({datasetSummary.rows} rows) →
              </button>
            </div>

            <div className="overflow-x-auto rounded-2xl border border-slate-800 bg-slate-900/40">
              <table className="w-full text-xs text-left border-collapse">
                <thead className="bg-slate-800/70 text-slate-300 text-[11px] uppercase font-mono tracking-wider border-b border-slate-800">
                  <tr>
                    <th className="p-3 text-center w-12 text-slate-500">#</th>
                    {datasetSummary.column_info?.map((col) => (
                      <th
                        key={col.name}
                        className={`p-3 whitespace-nowrap ${
                          col.name === datasetSummary.target_column ? 'text-rose-400 font-bold bg-rose-500/10' : ''
                        }`}
                      >
                        {col.name}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {datasetSummary.first_10_rows?.map((row, idx) => (
                    <tr key={idx} className="hover:bg-slate-800/30 transition-colors">
                      <td className="p-3 text-center text-slate-500 font-mono">{idx + 1}</td>
                      {datasetSummary.column_info?.map((col) => {
                        const val = row[col.name];
                        const isTarget = col.name === datasetSummary.target_column;
                        return (
                          <td
                            key={col.name}
                            className={`p-3 whitespace-nowrap font-mono ${
                              isTarget ? 'font-bold text-rose-400 bg-rose-500/5' : 'text-slate-300'
                            }`}
                          >
                            {val !== null && val !== undefined ? String(val) : <span className="text-slate-600 italic">null</span>}
                          </td>
                        );
                      })}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Column Information Table */}
          <div className="space-y-3">
            <div>
              <h4 className="text-sm font-bold text-slate-200 uppercase tracking-wider">
                Column Characteristics & Statistics
              </h4>
              <p className="text-xs text-slate-400">
                Detailed metadata including data types, missing records, unique values, and distribution ranges
              </p>
            </div>

            <div className="overflow-x-auto rounded-2xl border border-slate-800 bg-slate-900/40">
              <table className="w-full text-xs text-left border-collapse">
                <thead className="bg-slate-800/70 text-slate-300 text-[11px] uppercase font-mono tracking-wider border-b border-slate-800">
                  <tr>
                    <th className="p-3">Column</th>
                    <th className="p-3">Role</th>
                    <th className="p-3">Data Type</th>
                    <th className="p-3">Missing Values</th>
                    <th className="p-3">Unique Values</th>
                    <th className="p-3">Mean</th>
                    <th className="p-3">Min</th>
                    <th className="p-3">Max</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {datasetSummary.column_info?.map((col) => {
                    const isTarget = col.name === datasetSummary.target_column;
                    return (
                      <tr key={col.name} className="hover:bg-slate-800/30 transition-colors">
                        <td className="p-3 font-semibold text-slate-200 whitespace-nowrap font-mono">
                          {col.name}
                        </td>
                        <td className="p-3">
                          {isTarget ? (
                            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-rose-500/20 text-rose-400">
                              Target (y)
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 rounded text-[10px] font-medium bg-slate-800 text-slate-400">
                              Feature (X)
                            </span>
                          )}
                        </td>
                        <td className="p-3 font-mono text-slate-400">{col.dtype}</td>
                        <td className="p-3 font-mono">
                          {col.missing > 0 ? (
                            <span className="text-rose-400 font-bold">{col.missing}</span>
                          ) : (
                            <span className="text-emerald-400">0</span>
                          )}
                        </td>
                        <td className="p-3 font-mono text-slate-300">{col.unique}</td>
                        <td className="p-3 font-mono text-slate-400">{col.mean !== null ? col.mean : '-'}</td>
                        <td className="p-3 font-mono text-slate-400">{col.min !== null ? col.min : '-'}</td>
                        <td className="p-3 font-mono text-slate-400">{col.max !== null ? col.max : '-'}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Full Dataset Modal */}
      {fullModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-4 animate-in fade-in">
          <div className="w-full max-w-5xl h-[85vh] flex flex-col rounded-3xl bg-slate-900 border border-slate-700 shadow-2xl overflow-hidden">
            {/* Modal Header */}
            <div className="p-5 border-b border-slate-800 flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
                  <Table className="w-5 h-5 text-rose-400" />
                  Full Dataset Browser
                </h3>
                <p className="text-xs text-slate-400">
                  Showing {modalData.total} records from {datasetSummary?.filename}
                </p>
              </div>

              <div className="flex items-center space-x-3">
                {/* Search Box */}
                <div className="relative">
                  <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
                  <input
                    type="text"
                    placeholder="Search values..."
                    value={modalSearch}
                    onChange={(e) => {
                      setModalSearch(e.target.value);
                      fetchModalPage(1, e.target.value);
                    }}
                    className="pl-8 pr-3 py-1.5 rounded-xl bg-slate-800 border border-slate-700 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-rose-500"
                  />
                </div>

                <button
                  onClick={() => setFullModalOpen(false)}
                  className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Modal Table Content */}
            <div className="flex-1 overflow-auto p-4">
              {loadingModalData ? (
                <div className="h-full flex items-center justify-center text-slate-400 text-xs">
                  Loading records...
                </div>
              ) : (
                <table className="w-full text-xs text-left border-collapse">
                  <thead className="bg-slate-800/80 text-slate-300 text-[11px] uppercase font-mono tracking-wider sticky top-0 z-10">
                    <tr>
                      <th className="p-2.5 text-center text-slate-500">#</th>
                      {modalData.columns?.map((col) => (
                        <th key={col} className="p-2.5 whitespace-nowrap">
                          {col}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800">
                    {modalData.rows?.map((row, rIdx) => (
                      <tr key={rIdx} className="hover:bg-slate-800/40 font-mono text-slate-300">
                        <td className="p-2.5 text-center text-slate-500">
                          {(modalPage - 1) * 20 + rIdx + 1}
                        </td>
                        {modalData.columns?.map((col) => (
                          <td key={col} className="p-2.5 whitespace-nowrap">
                            {row[col] !== null ? String(row[col]) : '-'}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>

            {/* Modal Pagination */}
            <div className="p-4 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
              <span>
                Page {modalPage} of {modalData.total_pages}
              </span>
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => fetchModalPage(modalPage - 1, modalSearch)}
                  disabled={modalPage <= 1}
                  className="p-1.5 rounded-lg border border-slate-700 bg-slate-800 hover:bg-slate-700 disabled:opacity-40"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <button
                  onClick={() => fetchModalPage(modalPage + 1, modalSearch)}
                  disabled={modalPage >= modalData.total_pages}
                  className="p-1.5 rounded-lg border border-slate-700 bg-slate-800 hover:bg-slate-700 disabled:opacity-40"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
