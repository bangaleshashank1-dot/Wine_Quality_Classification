import React from 'react';
import {
  Layers,
  CheckCircle2,
  Target,
  TrendingUp,
  AlertCircle,
  HelpCircle
} from 'lucide-react';
import MetricCard from '../components/MetricCard';
import ConfusionMatrix from '../components/ConfusionMatrix';

export default function MulticlassClassificationPage({
  multinomialResults,
  isTrained,
  isDark
}) {
  const res = multinomialResults;

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 p-6 rounded-3xl bg-slate-900/60 border border-slate-800">
        <div className="space-y-1">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 rounded-xl bg-emerald-500/15 text-emerald-400 flex items-center justify-center">
              <Layers className="w-4 h-4" />
            </div>
            <h3 className="text-lg font-bold text-slate-100">
              Multinomial Logistic Regression Results
            </h3>
          </div>
          <p className="text-xs text-slate-400">
            Multi-class classification using Softmax cross-entropy loss across all discrete quality ratings.
          </p>
        </div>

        {isTrained && res && (
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400">Target Classes:</span>
            <div className="flex items-center gap-1.5">
              {res.classes?.map((cls) => (
                <span
                  key={cls}
                  className="px-2 py-0.5 rounded-md bg-emerald-500/15 text-emerald-400 font-mono font-bold text-xs"
                >
                  {cls}
                </span>
              ))}
            </div>
          </div>
        )}
      </div>

      {!isTrained || !res ? (
        <div className="p-12 rounded-3xl border border-dashed border-slate-800 bg-slate-900/40 text-center space-y-3">
          <AlertCircle className="w-10 h-10 text-amber-400 mx-auto" />
          <h4 className="text-base font-bold text-slate-200">Model Not Trained Yet</h4>
          <p className="text-xs text-slate-400 max-w-sm mx-auto">
            Click "Train Models" in the top bar to train the Multinomial Logistic Regression model on your dataset.
          </p>
        </div>
      ) : (
        <>
          {/* Key Metrics Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <MetricCard
              title="Overall Accuracy"
              value={`${(res.accuracy * 100).toFixed(2)}%`}
              subtitle="Fraction of exact quality matches"
              icon={CheckCircle2}
              color="emerald"
              isDark={isDark}
            />
            <MetricCard
              title="Weighted Precision"
              value={`${(res.precision * 100).toFixed(2)}%`}
              subtitle="Weighted by class frequency"
              icon={Target}
              color="sky"
              isDark={isDark}
            />
            <MetricCard
              title="Weighted Recall"
              value={`${(res.recall * 100).toFixed(2)}%`}
              subtitle="Weighted detection rate"
              icon={TrendingUp}
              color="amber"
              isDark={isDark}
            />
            <MetricCard
              title="Weighted F1-Score"
              value={res.f1_score.toFixed(4)}
              subtitle="Harmonic balance across classes"
              icon={Layers}
              color="rose"
              isDark={isDark}
            />
          </div>

          {/* Macro vs Weighted Comparison Pill */}
          <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800/80 flex flex-wrap items-center justify-between gap-4 text-xs">
            <div className="flex items-center space-x-2 text-slate-300">
              <HelpCircle className="w-4 h-4 text-sky-400" />
              <span>Averaging Method Breakdown:</span>
            </div>
            <div className="flex flex-wrap items-center gap-6 font-mono">
              <div>
                <span className="text-slate-500 mr-2">Macro Avg:</span>
                <span className="text-slate-300 font-bold">
                  P: {(res.macro_avg.precision * 100).toFixed(1)}% | R: {(res.macro_avg.recall * 100).toFixed(1)}% | F1: {res.macro_avg.f1.toFixed(4)}
                </span>
              </div>
              <div>
                <span className="text-slate-500 mr-2">Weighted Avg:</span>
                <span className="text-rose-400 font-bold">
                  P: {(res.weighted_avg.precision * 100).toFixed(1)}% | R: {(res.weighted_avg.recall * 100).toFixed(1)}% | F1: {res.weighted_avg.f1.toFixed(4)}
                </span>
              </div>
            </div>
          </div>

          {/* Multi-Class Confusion Matrix */}
          <div className="p-6 rounded-3xl bg-slate-900/60 border border-slate-800 shadow-md">
            <ConfusionMatrix
              matrixData={res.confusion_matrix}
              isBinary={false}
              isDark={isDark}
            />
          </div>

          {/* Class-wise Performance Report */}
          <div className="space-y-3">
            <div>
              <h4 className="text-sm font-bold text-slate-200 uppercase tracking-wider">
                Class-Wise Performance Breakdown
              </h4>
              <p className="text-xs text-slate-400">
                Individual precision, recall, and F1 scores for each detected wine quality level
              </p>
            </div>

            <div className="overflow-x-auto rounded-2xl border border-slate-800 bg-slate-900/40">
              <table className="w-full text-xs text-left border-collapse">
                <thead className="bg-slate-800/70 text-slate-300 text-[11px] uppercase font-mono tracking-wider border-b border-slate-800">
                  <tr>
                    <th className="p-3">Quality Class</th>
                    <th className="p-3">Precision</th>
                    <th className="p-3">Recall</th>
                    <th className="p-3">F1-Score</th>
                    <th className="p-3">Support (Test Samples)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 font-mono">
                  {res.classification_report?.map((row) => (
                    <tr key={row.class} className="hover:bg-slate-800/30">
                      <td className="p-3 font-semibold text-emerald-400">
                        {row.class}
                      </td>
                      <td className="p-3 text-slate-300">{(row.precision * 100).toFixed(2)}%</td>
                      <td className="p-3 text-slate-300">{(row.recall * 100).toFixed(2)}%</td>
                      <td className="p-3 text-slate-300">{row.f1.toFixed(4)}</td>
                      <td className="p-3 text-slate-400">{row.support}</td>
                    </tr>
                  ))}
                  {/* Macro Row */}
                  <tr className="bg-slate-800/30 font-semibold text-slate-300">
                    <td className="p-3">Macro Average</td>
                    <td className="p-3">{(res.macro_avg.precision * 100).toFixed(2)}%</td>
                    <td className="p-3">{(res.macro_avg.recall * 100).toFixed(2)}%</td>
                    <td className="p-3">{res.macro_avg.f1.toFixed(4)}</td>
                    <td className="p-3">-</td>
                  </tr>
                  {/* Weighted Row */}
                  <tr className="bg-slate-800/50 font-bold text-emerald-300">
                    <td className="p-3">Weighted Average</td>
                    <td className="p-3">{(res.weighted_avg.precision * 100).toFixed(2)}%</td>
                    <td className="p-3">{(res.weighted_avg.recall * 100).toFixed(2)}%</td>
                    <td className="p-3">{res.weighted_avg.f1.toFixed(4)}</td>
                    <td className="p-3">-</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
