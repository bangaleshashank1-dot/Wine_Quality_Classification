import React, { useState } from 'react';
import {
  Binary,
  CheckCircle2,
  Sliders,
  Play,
  TrendingUp,
  Target,
  FileText,
  AlertCircle
} from 'lucide-react';
import MetricCard from '../components/MetricCard';
import ConfusionMatrix from '../components/ConfusionMatrix';
import RocCurveChart from '../components/RocCurveChart';

export default function BinaryClassificationPage({
  logisticResults,
  isTrained,
  onRetrainWithThreshold,
  isTraining,
  isDark
}) {
  const [threshold, setThreshold] = useState(6);

  const res = logisticResults;

  const handleThresholdSubmit = (e) => {
    e.preventDefault();
    onRetrainWithThreshold(threshold);
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      {/* Header & Threshold Selector */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 p-6 rounded-3xl bg-slate-900/60 border border-slate-800">
        <div className="space-y-1">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 rounded-xl bg-rose-500/15 text-rose-400 flex items-center justify-center">
              <Binary className="w-4 h-4" />
            </div>
            <h3 className="text-lg font-bold text-slate-100">
              Binary Logistic Regression Results
            </h3>
          </div>
          <p className="text-xs text-slate-400">
            Partitioning wine quality into two distinct categories based on physicochemical properties.
          </p>
        </div>

        {/* Interactive Threshold Configuration */}
        <form onSubmit={handleThresholdSubmit} className="flex flex-wrap items-center gap-3">
          <div className="flex items-center space-x-2 text-xs">
            <span className="text-slate-400 font-medium">Quality Threshold:</span>
            <select
              value={threshold}
              onChange={(e) => setThreshold(Number(e.target.value))}
              className="px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-rose-400 font-bold font-mono text-xs focus:outline-none focus:border-rose-500"
            >
              <option value={5}>Quality ≥ 5 (Good) vs &lt; 5 (Poor)</option>
              <option value={6}>Quality ≥ 6 (Good) vs &lt; 6 (Poor) [Default]</option>
              <option value={7}>Quality ≥ 7 (Good) vs &lt; 7 (Poor)</option>
            </select>
          </div>

          <button
            type="submit"
            disabled={isTraining}
            className="flex items-center space-x-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-rose-600 to-pink-600 hover:from-rose-500 hover:to-pink-500 text-white text-xs font-bold shadow-md shadow-rose-600/30 transition-all disabled:opacity-50"
          >
            <Sliders className="w-3.5 h-3.5" />
            <span>Apply & Retrain</span>
          </button>
        </form>
      </div>

      {!isTrained || !res ? (
        <div className="p-12 rounded-3xl border border-dashed border-slate-800 bg-slate-900/40 text-center space-y-3">
          <AlertCircle className="w-10 h-10 text-amber-400 mx-auto" />
          <h4 className="text-base font-bold text-slate-200">Model Not Trained Yet</h4>
          <p className="text-xs text-slate-400 max-w-sm mx-auto">
            Click "Train Models" in the top bar or apply a quality threshold to train the binary Logistic Regression model.
          </p>
        </div>
      ) : (
        <>
          {/* Key Evaluation Metrics */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
            <MetricCard
              title="Accuracy"
              value={`${(res.accuracy * 100).toFixed(2)}%`}
              subtitle="Overall correct predictions"
              icon={CheckCircle2}
              color="emerald"
              isDark={isDark}
            />
            <MetricCard
              title="Precision"
              value={`${(res.precision * 100).toFixed(2)}%`}
              subtitle="Positive predictive value"
              icon={Target}
              color="sky"
              isDark={isDark}
            />
            <MetricCard
              title="Recall"
              value={`${(res.recall * 100).toFixed(2)}%`}
              subtitle="Sensitivity / Hit rate"
              icon={TrendingUp}
              color="amber"
              isDark={isDark}
            />
            <MetricCard
              title="F1-Score"
              value={res.f1_score.toFixed(4)}
              subtitle="Harmonic mean of P & R"
              icon={Binary}
              color="rose"
              isDark={isDark}
            />
            <MetricCard
              title="ROC-AUC"
              value={res.roc_auc.toFixed(4)}
              subtitle="Area under ROC curve"
              icon={Sliders}
              color="purple"
              isDark={isDark}
            />
          </div>

          {/* Visualizations: Confusion Matrix & ROC Curve */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Confusion Matrix Card */}
            <div className="p-6 rounded-3xl bg-slate-900/60 border border-slate-800 shadow-md">
              <ConfusionMatrix
                matrixData={res.confusion_matrix}
                isBinary={true}
                isDark={isDark}
              />
            </div>

            {/* ROC Curve Card */}
            <div className="p-6 rounded-3xl bg-slate-900/60 border border-slate-800 shadow-md">
              <RocCurveChart
                rocPoints={res.roc_curve}
                aucValue={res.roc_auc}
                isDark={isDark}
              />
            </div>
          </div>

          {/* Classification Report Table */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-sm font-bold text-slate-200 uppercase tracking-wider">
                  Detailed Classification Report
                </h4>
                <p className="text-xs text-slate-400">
                  Precision, Recall, F1-Score, and Support breakdown for each binary category
                </p>
              </div>
              <span className="text-xs font-mono text-slate-400">
                Decision Threshold: Quality ≥ {res.threshold || 6}
              </span>
            </div>

            <div className="overflow-x-auto rounded-2xl border border-slate-800 bg-slate-900/40">
              <table className="w-full text-xs text-left border-collapse">
                <thead className="bg-slate-800/70 text-slate-300 text-[11px] uppercase font-mono tracking-wider border-b border-slate-800">
                  <tr>
                    <th className="p-3">Class Category</th>
                    <th className="p-3">Precision</th>
                    <th className="p-3">Recall</th>
                    <th className="p-3">F1-Score</th>
                    <th className="p-3">Support (Test Samples)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 font-mono">
                  {res.classification_report?.map((row) => (
                    <tr key={row.class} className="hover:bg-slate-800/30">
                      <td className="p-3 font-semibold text-slate-100 flex items-center gap-2">
                        <span
                          className={`w-2.5 h-2.5 rounded-full ${
                            row.class === 'Good' ? 'bg-emerald-400' : 'bg-rose-400'
                          }`}
                        />
                        {row.class} Wine ({row.class === 'Good' ? `≥ ${res.threshold || 6}` : `< ${res.threshold || 6}`})
                      </td>
                      <td className="p-3 text-slate-300">{(row.precision * 100).toFixed(2)}%</td>
                      <td className="p-3 text-slate-300">{(row.recall * 100).toFixed(2)}%</td>
                      <td className="p-3 text-slate-300">{row.f1.toFixed(4)}</td>
                      <td className="p-3 text-slate-400">{row.support}</td>
                    </tr>
                  ))}
                  {/* Macro Avg Row */}
                  <tr className="bg-slate-800/30 font-semibold text-slate-300">
                    <td className="p-3">Macro Average</td>
                    <td className="p-3">{(res.macro_avg.precision * 100).toFixed(2)}%</td>
                    <td className="p-3">{(res.macro_avg.recall * 100).toFixed(2)}%</td>
                    <td className="p-3">{res.macro_avg.f1.toFixed(4)}</td>
                    <td className="p-3">-</td>
                  </tr>
                  {/* Weighted Avg Row */}
                  <tr className="bg-slate-800/50 font-bold text-rose-300">
                    <td className="p-3">Weighted Average</td>
                    <td className="p-3">{(res.weighted_avg.precision * 100).toFixed(2)}%</td>
                    <td className="p-3">{(res.weighted_avg.recall * 100).toFixed(2)}%</td>
                    <td className="p-3">{res.weighted_avg.f1.toFixed(4)}</td>
                    <td className="p-3">-</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
