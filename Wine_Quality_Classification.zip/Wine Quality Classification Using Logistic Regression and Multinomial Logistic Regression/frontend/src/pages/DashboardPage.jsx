import React from 'react';
import {
  Database,
  Columns,
  Sparkles,
  Binary,
  Layers,
  TrendingUp,
  UploadCloud,
  FileSpreadsheet,
  ArrowRight,
  ShieldCheck,
  CheckCircle2
} from 'lucide-react';
import MetricCard from '../components/MetricCard';
import WorkflowBanner from '../components/WorkflowBanner';

export default function DashboardPage({
  datasetSummary,
  logisticResults,
  multinomialResults,
  isTrained,
  setActiveTab,
  onLoadSample,
  isDark
}) {
  const hasData = datasetSummary && datasetSummary.status === 'loaded';

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      {/* Hero Section */}
      <div className="relative overflow-hidden rounded-3xl p-8 bg-gradient-to-br from-rose-950/40 via-slate-900 to-slate-950 border border-rose-500/20 shadow-2xl">
        <div className="absolute top-0 right-0 -mt-12 -mr-12 w-96 h-96 bg-rose-600/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 max-w-3xl space-y-4">
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-rose-500/15 border border-rose-500/30 text-rose-400 text-xs font-semibold uppercase tracking-wider">
            <span>🎓 B.Tech Machine Learning Project</span>
          </div>

          <h1 className="text-3xl sm:text-4xl font-black text-slate-100 tracking-tight leading-tight">
            Wine Quality Classification
          </h1>
          <p className="text-lg font-medium text-rose-400">
            Machine Learning using Logistic Regression and Multinomial Logistic Regression
          </p>

          <p className="text-sm text-slate-300 leading-relaxed max-w-2xl">
            Wine quality can be predicted using physicochemical properties of wine. This application uses{' '}
            <strong className="text-white">Logistic Regression</strong> for binary classification (Poor vs Good) and{' '}
            <strong className="text-white">Multinomial Logistic Regression</strong> for granular multi-class quality rating.
          </p>

          {/* Action Buttons */}
          <div className="pt-2 flex flex-wrap items-center gap-3">
            <button
              onClick={() => setActiveTab('dataset')}
              className="flex items-center space-x-2 px-5 py-3 rounded-2xl bg-gradient-to-r from-rose-600 to-pink-600 hover:from-rose-500 hover:to-pink-500 text-white font-bold text-sm shadow-lg shadow-rose-600/30 transition-all"
            >
              <UploadCloud className="w-4 h-4" />
              <span>Upload Dataset</span>
            </button>

            <button
              onClick={() => onLoadSample('red')}
              className="flex items-center space-x-2 px-5 py-3 rounded-2xl bg-slate-800/90 hover:bg-slate-700 text-slate-200 border border-slate-700 font-semibold text-sm transition-all"
            >
              <FileSpreadsheet className="w-4 h-4 text-rose-400" />
              <span>Load UCI Sample Data</span>
            </button>

            {isTrained && (
              <button
                onClick={() => setActiveTab('comparison')}
                className="flex items-center space-x-2 px-5 py-3 rounded-2xl bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-300 border border-emerald-500/30 font-semibold text-sm transition-all"
              >
                <span>Explore Comparison</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Workflow Banner */}
      <WorkflowBanner
        activeTab="dashboard"
        setActiveTab={setActiveTab}
        datasetLoaded={hasData}
        isTrained={isTrained}
      />

      {/* Statistics Cards */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold uppercase tracking-wider text-slate-400">
            Project Key Metrics
          </h3>
          {hasData && (
            <span className="text-xs text-slate-400 font-mono">
              Dataset: {datasetSummary.filename}
            </span>
          )}
        </div>

        {hasData ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
            <MetricCard
              title="Dataset Rows"
              value={datasetSummary.rows ? datasetSummary.rows.toLocaleString() : '0'}
              subtitle="Total wine samples"
              icon={Database}
              color="indigo"
              isDark={isDark}
            />
            <MetricCard
              title="Dataset Columns"
              value={datasetSummary.columns || '0'}
              subtitle="Attributes measured"
              icon={Columns}
              color="sky"
              isDark={isDark}
            />
            <MetricCard
              title="Features"
              value={datasetSummary.num_features || '0'}
              subtitle="Physicochemical inputs"
              icon={Sparkles}
              color="amber"
              isDark={isDark}
            />
            <MetricCard
              title="Target Classes"
              value={datasetSummary.num_classes || '0'}
              subtitle={`Classes: ${datasetSummary.classes?.join(', ')}`}
              icon={Layers}
              color="purple"
              isDark={isDark}
            />
            <MetricCard
              title="Logistic Reg. Acc"
              value={isTrained && logisticResults?.accuracy !== undefined ? `${(logisticResults.accuracy * 100).toFixed(1)}%` : 'Untrained'}
              subtitle="Binary (Poor vs Good)"
              icon={Binary}
              color="rose"
              isDark={isDark}
            />
            <MetricCard
              title="Multinomial Acc"
              value={isTrained && multinomialResults?.accuracy !== undefined ? `${(multinomialResults.accuracy * 100).toFixed(1)}%` : 'Untrained'}
              subtitle="Multi-class classification"
              icon={TrendingUp}
              color="emerald"
              isDark={isDark}
            />
          </div>
        ) : (
          /* Empty State */
          <div className="p-12 rounded-3xl border border-dashed border-slate-800 bg-slate-900/30 text-center space-y-4">
            <div className="w-16 h-16 mx-auto rounded-2xl bg-rose-500/10 border border-rose-500/20 flex items-center justify-center text-3xl">
              📂
            </div>
            <div className="space-y-1 max-w-md mx-auto">
              <h4 className="text-base font-bold text-slate-200">No dataset uploaded yet</h4>
              <p className="text-xs text-slate-400">
                Upload a CSV or Excel wine-quality dataset to begin training Logistic Regression and Multinomial Logistic Regression models.
              </p>
            </div>
            <div className="pt-2 flex justify-center gap-3">
              <button
                onClick={() => setActiveTab('dataset')}
                className="px-5 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold shadow-md shadow-rose-600/30 transition-all"
              >
                Upload Dataset
              </button>
              <button
                onClick={() => onLoadSample('red')}
                className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold transition-all"
              >
                Load Sample Dataset
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Overview Highlights */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Binary Logistic Card */}
        <div className="p-6 rounded-3xl bg-slate-900/60 border border-slate-800/80 space-y-3">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-rose-500/15 text-rose-400 flex items-center justify-center">
              <Binary className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-base font-bold text-slate-100">Logistic Regression (Binary)</h4>
              <p className="text-xs text-slate-400">Supervised classification for quality thresholding</p>
            </div>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            Converts quality into two discrete buckets: <strong>Poor Wine (&lt; 6)</strong> and <strong>Good Wine (&ge; 6)</strong>.
            Uses sigmoid activation and binary cross-entropy loss to produce class probabilities and ROC curves.
          </p>
          <div className="flex items-center gap-4 text-xs font-mono text-slate-400 pt-2 border-t border-slate-800">
            <span>Loss: Binary Cross-Entropy</span>
            <span>•</span>
            <span>Activation: Sigmoid σ(z)</span>
          </div>
        </div>

        {/* Multinomial Logistic Card */}
        <div className="p-6 rounded-3xl bg-slate-900/60 border border-slate-800/80 space-y-3">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/15 text-emerald-400 flex items-center justify-center">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-base font-bold text-slate-100">Multinomial Logistic Regression</h4>
              <p className="text-xs text-slate-400">Multi-class classification using Softmax</p>
            </div>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            Predicts the exact discrete quality rating (e.g. 3, 4, 5, 6, 7, 8) without grouping.
            Employs the softmax function to model a generalized probability distribution across all K classes simultaneously.
          </p>
          <div className="flex items-center gap-4 text-xs font-mono text-slate-400 pt-2 border-t border-slate-800">
            <span>Loss: Categorical Cross-Entropy</span>
            <span>•</span>
            <span>Activation: Softmax</span>
          </div>
        </div>
      </div>
    </div>
  );
}
