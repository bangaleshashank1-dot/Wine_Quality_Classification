import React from 'react';
import {
  LayoutDashboard,
  Database,
  GitBranch,
  Binary,
  Layers,
  GitCompare,
  Sparkles,
  BarChart3,
  Info,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';

export default function Sidebar({ activeTab, setActiveTab, datasetSummary, isTrained, isDark }) {
  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'dataset', label: 'Dataset', icon: Database, badge: datasetSummary?.rows ? `${datasetSummary.rows} rows` : null },
    { id: 'preprocessing', label: 'Preprocessing', icon: GitBranch },
    { id: 'binary', label: 'Binary Classification', icon: Binary, subtitle: 'Logistic Regression' },
    { id: 'multiclass', label: 'Multi-Class ML', icon: Layers, subtitle: 'Multinomial Logistic' },
    { id: 'comparison', label: 'Model Comparison', icon: GitCompare },
    { id: 'prediction', label: 'Wine Prediction', icon: Sparkles, highlight: true },
    { id: 'visualizations', label: 'Visualizations', icon: BarChart3 },
    { id: 'about', label: 'About Project', icon: Info },
  ];

  return (
    <aside className={`w-72 flex-shrink-0 flex flex-col border-r transition-colors duration-200 ${
      isDark ? 'bg-slate-900/90 border-slate-800 text-slate-200' : 'bg-white/95 border-rose-100 text-slate-800'
    }`}>
      {/* Brand Header */}
      <div className="p-5 border-b border-rose-500/10 flex items-center space-x-3">
        <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-rose-500 to-pink-700 flex items-center justify-center text-2xl shadow-lg shadow-rose-900/30">
          🍷
        </div>
        <div>
          <h1 className="font-bold text-lg tracking-tight flex items-center gap-1.5">
            Wine Quality <span className="text-rose-500 font-extrabold text-sm uppercase px-1.5 py-0.5 bg-rose-500/10 rounded-md">ML</span>
          </h1>
          <p className="text-xs text-slate-400 font-medium">B.Tech ML Project</p>
        </div>
      </div>

      {/* Nav List */}
      <nav className="flex-1 px-3 py-4 space-y-1.5 overflow-y-auto">
        <div className="px-3 pb-2 text-[11px] font-semibold uppercase tracking-wider text-slate-500">
          Navigation Menu
        </div>

        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-sm font-medium transition-all duration-200 ${
                isActive
                  ? 'bg-gradient-to-r from-rose-600 to-pink-600 text-white shadow-md shadow-rose-600/25 font-semibold translate-x-1'
                  : isDark
                  ? 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
                  : 'text-slate-600 hover:bg-rose-50/80 hover:text-rose-700'
              }`}
            >
              <div className="flex items-center space-x-3 text-left truncate">
                <Icon className={`w-5 h-5 flex-shrink-0 ${isActive ? 'text-white' : item.highlight ? 'text-amber-400' : 'text-slate-400'}`} />
                <div className="truncate">
                  <div className="truncate">{item.label}</div>
                  {item.subtitle && (
                    <div className={`text-[10px] truncate ${isActive ? 'text-rose-100' : 'text-slate-500'}`}>
                      {item.subtitle}
                    </div>
                  )}
                </div>
              </div>

              {item.badge && (
                <span className={`text-[10px] px-2 py-0.5 rounded-full font-semibold ${
                  isActive ? 'bg-white/20 text-white' : 'bg-rose-500/15 text-rose-400'
                }`}>
                  {item.badge}
                </span>
              )}

              {item.highlight && !isActive && (
                <span className="flex h-2 w-2 relative">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-rose-500"></span>
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* System Status Card */}
      <div className="p-4 m-3 rounded-2xl border bg-slate-950/40 border-slate-800/80 space-y-2.5">
        <div className="text-xs font-medium text-slate-400 flex items-center justify-between">
          <span>Project Status</span>
          <span className="text-[10px] px-1.5 py-0.5 bg-emerald-500/10 text-emerald-400 rounded">Active</span>
        </div>

        <div className="space-y-1.5 text-xs">
          <div className="flex items-center justify-between text-slate-300">
            <span className="flex items-center gap-1.5">
              {datasetSummary?.rows ? (
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              ) : (
                <AlertCircle className="w-3.5 h-3.5 text-amber-400" />
              )}
              Dataset
            </span>
            <span className="font-mono text-[11px] text-slate-400">
              {datasetSummary?.rows ? `${datasetSummary.rows} rows` : 'None'}
            </span>
          </div>

          <div className="flex items-center justify-between text-slate-300">
            <span className="flex items-center gap-1.5">
              {isTrained ? (
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              ) : (
                <div className="w-3.5 h-3.5 rounded-full border border-slate-600 flex items-center justify-center">
                  <div className="w-1.5 h-1.5 bg-slate-600 rounded-full" />
                </div>
              )}
              Models
            </span>
            <span className="font-mono text-[11px] text-slate-400">
              {isTrained ? 'Trained' : 'Untrained'}
            </span>
          </div>
        </div>
      </div>
    </aside>
  );
}
