import React from 'react';
import {
  UploadCloud,
  Sliders,
  Cpu,
  LineChart,
  GitCompare,
  Sparkles,
  ChevronRight,
  Check
} from 'lucide-react';

export default function WorkflowBanner({ activeTab, setActiveTab, datasetLoaded, isTrained }) {
  const steps = [
    { id: 'dataset', label: 'Upload Dataset', icon: UploadCloud, done: datasetLoaded },
    { id: 'preprocessing', label: 'Preprocess Data', icon: Sliders, done: datasetLoaded },
    { id: 'binary', label: 'Train Models', icon: Cpu, done: isTrained },
    { id: 'multiclass', label: 'Evaluate Models', icon: LineChart, done: isTrained },
    { id: 'comparison', label: 'Compare Results', icon: GitCompare, done: isTrained },
    { id: 'prediction', label: 'Predict Quality', icon: Sparkles, done: isTrained },
  ];

  return (
    <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800/80 shadow-sm overflow-x-auto">
      <div className="flex items-center min-w-max space-x-2">
        <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mr-2">
          Project Pipeline:
        </span>

        {steps.map((step, idx) => {
          const Icon = step.icon;
          const isCurrent = activeTab === step.id;

          return (
            <React.Fragment key={step.id}>
              <button
                onClick={() => setActiveTab(step.id)}
                className={`flex items-center space-x-2 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all duration-150 ${
                  isCurrent
                    ? 'bg-rose-600 text-white shadow-md shadow-rose-600/30'
                    : step.done
                    ? 'bg-slate-800/80 text-emerald-400 border border-emerald-500/30 hover:bg-slate-800'
                    : 'bg-slate-900/40 text-slate-400 border border-slate-800 hover:text-slate-300'
                }`}
              >
                {step.done ? (
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                ) : (
                  <Icon className="w-3.5 h-3.5" />
                )}
                <span>{step.label}</span>
              </button>

              {idx < steps.length - 1 && (
                <ChevronRight className="w-4 h-4 text-slate-600 flex-shrink-0" />
              )}
            </React.Fragment>
          );
        })}
      </div>
    </div>
  );
}
