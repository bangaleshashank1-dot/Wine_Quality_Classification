import React, { useState } from 'react';
import {
  Sun,
  Moon,
  Play,
  Download,
  FileSpreadsheet,
  Menu,
  ChevronDown,
  Sparkles,
  Loader2
} from 'lucide-react';

export default function Topbar({
  activeTab,
  isDark,
  setIsDark,
  onTrain,
  isTraining,
  onLoadSample,
  datasetLoaded,
  isTrained,
  onDownloadReport,
  onToggleMobileSidebar
}) {
  const [sampleDropdownOpen, setSampleDropdownOpen] = useState(false);

  const getPageTitle = () => {
    switch (activeTab) {
      case 'dashboard': return { title: 'Project Dashboard', subtitle: 'Overview of Machine Learning wine quality classification' };
      case 'dataset': return { title: 'Dataset Management', subtitle: 'Upload CSV or Excel files & inspect physicochemical features' };
      case 'preprocessing': return { title: 'Data Preprocessing', subtitle: '6-Step automated data cleaning, imputation, and scaling pipeline' };
      case 'binary': return { title: 'Binary Logistic Regression', subtitle: 'Quality classification into Poor (< 6) and Good (>= 6)' };
      case 'multiclass': return { title: 'Multinomial Logistic Regression', subtitle: 'Fine-grained multi-class classification across quality grades' };
      case 'comparison': return { title: 'Model Comparison', subtitle: 'Side-by-side performance evaluation & dynamic metrics report' };
      case 'prediction': return { title: 'Wine Quality Predictor', subtitle: 'Real-time inference using trained models with probability distributions' };
      case 'visualizations': return { title: 'Visualizations & Exploratory Analysis', subtitle: 'Quality distribution, histograms, and correlation heatmaps' };
      case 'about': return { title: 'About Project & Viva Guide', subtitle: 'Student credentials, methodology, and theoretical ML concepts' };
      default: return { title: 'Wine Quality ML', subtitle: 'Machine Learning Classification' };
    }
  };

  const pageInfo = getPageTitle();

  return (
    <header className={`h-20 px-6 border-b flex items-center justify-between transition-colors duration-200 z-10 ${
      isDark ? 'bg-slate-900/80 border-slate-800' : 'bg-white/80 border-rose-100 shadow-sm'
    } backdrop-blur-md sticky top-0`}>
      {/* Page Title & Mobile Toggle */}
      <div className="flex items-center space-x-4">
        <button
          onClick={onToggleMobileSidebar}
          className="md:hidden p-2 rounded-xl text-slate-400 hover:text-slate-100 hover:bg-slate-800"
        >
          <Menu className="w-6 h-6" />
        </button>

        <div>
          <h2 className="text-xl font-bold tracking-tight text-slate-100 flex items-center gap-2">
            {pageInfo.title}
          </h2>
          <p className="text-xs text-slate-400 font-medium hidden sm:block">
            {pageInfo.subtitle}
          </p>
        </div>
      </div>

      {/* Action Toolbar */}
      <div className="flex items-center space-x-3">
        {/* Sample Dataset Dropdown */}
        <div className="relative">
          <button
            onClick={() => setSampleDropdownOpen(!sampleDropdownOpen)}
            className="flex items-center space-x-2 px-3.5 py-2 rounded-xl text-xs font-semibold bg-slate-800/80 hover:bg-slate-700 text-slate-200 border border-slate-700/80 transition-all duration-150"
          >
            <FileSpreadsheet className="w-4 h-4 text-rose-400" />
            <span className="hidden sm:inline">Load Sample Data</span>
            <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
          </button>

          {sampleDropdownOpen && (
            <div
              className={`absolute right-0 mt-2 w-56 rounded-2xl border shadow-2xl p-2 z-50 ${
                isDark ? 'bg-slate-900 border-slate-800 text-slate-200' : 'bg-white border-slate-200 text-slate-800'
              }`}
            >
              <div className="px-3 py-1.5 text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                Pre-Packaged UCI Datasets
              </div>
              <button
                onClick={() => {
                  onLoadSample('red');
                  setSampleDropdownOpen(false);
                }}
                className="w-full text-left px-3 py-2 rounded-xl text-xs hover:bg-rose-500/10 hover:text-rose-400 flex items-center justify-between"
              >
                <span>🍷 Red Wine (CSV - 1,599 rows)</span>
                <span className="text-[10px] text-slate-500 font-mono">.csv</span>
              </button>
              <button
                onClick={() => {
                  onLoadSample('red_excel');
                  setSampleDropdownOpen(false);
                }}
                className="w-full text-left px-3 py-2 rounded-xl text-xs hover:bg-rose-500/10 hover:text-rose-400 flex items-center justify-between"
              >
                <span>📊 Red Wine (Excel Format)</span>
                <span className="text-[10px] text-emerald-400 font-mono">.xlsx</span>
              </button>
              <button
                onClick={() => {
                  onLoadSample('white');
                  setSampleDropdownOpen(false);
                }}
                className="w-full text-left px-3 py-2 rounded-xl text-xs hover:bg-rose-500/10 hover:text-rose-400 flex items-center justify-between"
              >
                <span>🥂 White Wine (CSV - 4,898 rows)</span>
                <span className="text-[10px] text-slate-500 font-mono">.csv</span>
              </button>
            </div>
          )}
        </div>

        {/* Train Models Button */}
        <button
          onClick={onTrain}
          disabled={!datasetLoaded || isTraining}
          className={`flex items-center space-x-2 px-4 py-2 rounded-xl text-xs font-bold transition-all shadow-md ${
            !datasetLoaded
              ? 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700/50'
              : isTraining
              ? 'bg-rose-700 text-white cursor-wait'
              : 'bg-gradient-to-r from-rose-600 via-pink-600 to-rose-600 hover:from-rose-500 hover:to-pink-500 text-white shadow-rose-600/30'
          }`}
        >
          {isTraining ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              <span>Training...</span>
            </>
          ) : (
            <>
              <Play className="w-4 h-4 fill-white" />
              <span>Train Models</span>
            </>
          )}
        </button>

        {/* Download Report Button (available when trained) */}
        {isTrained && (
          <button
            onClick={onDownloadReport}
            className="flex items-center space-x-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold bg-emerald-600/15 hover:bg-emerald-600/25 text-emerald-400 border border-emerald-500/30 transition-all"
            title="Download Comprehensive Evaluation Report"
          >
            <Download className="w-4 h-4" />
            <span className="hidden md:inline">Report</span>
          </button>
        )}

        {/* Theme Toggle */}
        <button
          onClick={() => setIsDark(!isDark)}
          className={`p-2 rounded-xl border transition-colors ${
            isDark
              ? 'bg-slate-800/80 border-slate-700 text-amber-300 hover:bg-slate-700'
              : 'bg-slate-100 border-slate-200 text-slate-600 hover:bg-slate-200'
          }`}
          title={isDark ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
        >
          {isDark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
        </button>
      </div>
    </header>
  );
}
