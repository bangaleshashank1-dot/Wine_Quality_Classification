import React from 'react';

export default function ConfusionMatrix({ matrixData, isBinary = false, isDark = true }) {
  if (!matrixData || !matrixData.matrix || matrixData.matrix.length === 0) {
    return (
      <div className="p-8 text-center text-slate-500 text-sm italic">
        Confusion matrix will appear after training.
      </div>
    );
  }

  const { matrix, labels, total } = matrixData;
  const maxVal = Math.max(...matrix.flat(), 1);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h4 className="text-sm font-bold text-slate-200 uppercase tracking-wider">
            Confusion Matrix (Actual vs Predicted)
          </h4>
          <p className="text-xs text-slate-400">
            Diagonal cells represent correct predictions (True Positives & True Negatives).
          </p>
        </div>
        <span className="text-xs font-mono px-2.5 py-1 rounded-lg bg-slate-800 text-slate-300 border border-slate-700">
          Total Test Samples: {total}
        </span>
      </div>

      <div className="overflow-x-auto pb-2">
        <div className="inline-block min-w-full align-middle">
          {/* Top Label: Predicted */}
          <div className="text-center font-bold text-xs uppercase tracking-widest text-rose-400 mb-2">
            Predicted Class →
          </div>

          <div className="flex">
            {/* Left Label: Actual */}
            <div className="flex items-center justify-center -rotate-90 text-xs font-bold uppercase tracking-widest text-sky-400 w-8 flex-shrink-0">
              Actual Class
            </div>

            {/* Matrix Table */}
            <div className="flex-1">
              <table className="w-full border-collapse">
                <thead>
                  <tr>
                    <th className="p-2 text-xs font-semibold text-slate-500 text-left border-b border-slate-800">
                      Actual \ Pred
                    </th>
                    {labels.map((lbl, idx) => (
                      <th
                        key={idx}
                        className="p-2.5 text-xs font-bold text-center text-slate-300 border-b border-slate-800 bg-slate-800/40"
                      >
                        {isBinary ? (lbl === '0' || lbl === 0 || lbl === 'Poor' ? 'Poor (<6)' : 'Good (≥6)') : `Class ${lbl}`}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {matrix.map((row, rIdx) => {
                    const rowSum = row.reduce((a, b) => a + b, 0);
                    const actualLabel = labels[rIdx];
                    return (
                      <tr key={rIdx} className="border-b border-slate-800/60">
                        <td className="p-2.5 text-xs font-bold text-slate-300 bg-slate-800/40 whitespace-nowrap">
                          {isBinary ? (actualLabel === '0' || actualLabel === 0 || actualLabel === 'Poor' ? 'Poor (<6)' : 'Good (≥6)') : `Class ${actualLabel}`}
                          <span className="ml-1 text-[10px] text-slate-500 font-normal">
                            (n={rowSum})
                          </span>
                        </td>

                        {row.map((val, cIdx) => {
                          const isDiagonal = rIdx === cIdx;
                          const intensity = Math.min(Math.round((val / maxVal) * 100), 100);
                          const percentage = rowSum > 0 ? ((val / rowSum) * 100).toFixed(1) : '0';

                          return (
                            <td
                              key={cIdx}
                              className="p-3 text-center relative transition-all duration-150 group"
                              style={{
                                backgroundColor: isDiagonal
                                  ? `rgba(225, 29, 72, ${Math.max(0.12, intensity / 130)})`
                                  : val > 0
                                  ? `rgba(51, 65, 85, ${Math.max(0.15, intensity / 200)})`
                                  : 'transparent',
                              }}
                            >
                              <div className="font-mono text-base font-extrabold text-slate-100">
                                {val}
                              </div>
                              <div className="text-[10px] text-slate-400 font-medium">
                                {percentage}%
                              </div>

                              {/* Hover Tooltip */}
                              <div className="absolute inset-0 border-2 border-transparent group-hover:border-rose-400/60 rounded pointer-events-none transition-all" />
                            </td>
                          );
                        })}
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      {/* Binary Breakdown Quick Cards */}
      {isBinary && matrixData.tn !== undefined && (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2">
          <div className="p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-center">
            <div className="text-[11px] font-semibold text-emerald-400 uppercase">True Negative (TN)</div>
            <div className="text-xl font-bold font-mono text-slate-100">{matrixData.tn}</div>
            <div className="text-[10px] text-slate-400">Poor wine correctly flagged</div>
          </div>
          <div className="p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-center">
            <div className="text-[11px] font-semibold text-emerald-400 uppercase">True Positive (TP)</div>
            <div className="text-xl font-bold font-mono text-slate-100">{matrixData.tp}</div>
            <div className="text-[10px] text-slate-400">Good wine correctly flagged</div>
          </div>
          <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/20 text-center">
            <div className="text-[11px] font-semibold text-amber-400 uppercase">False Positive (FP)</div>
            <div className="text-xl font-bold font-mono text-slate-100">{matrixData.fp}</div>
            <div className="text-[10px] text-slate-400">Type I Error (Poor as Good)</div>
          </div>
          <div className="p-2.5 rounded-xl bg-rose-500/10 border border-rose-500/20 text-center">
            <div className="text-[11px] font-semibold text-rose-400 uppercase">False Negative (FN)</div>
            <div className="text-xl font-bold font-mono text-slate-100">{matrixData.fn}</div>
            <div className="text-[10px] text-slate-400">Type II Error (Good as Poor)</div>
          </div>
        </div>
      )}
    </div>
  );
}
