import React, { useState } from 'react';

export default function CorrelationHeatmap({ correlationData, isDark = true }) {
  const [hoveredCell, setHoveredCell] = useState(null);

  if (!correlationData || !correlationData.columns || correlationData.columns.length === 0) {
    return (
      <div className="p-8 text-center text-slate-500 text-sm italic">
        Upload a dataset to view the correlation heatmap.
      </div>
    );
  }

  const { columns, matrix } = correlationData;

  // Function to determine cell background color based on correlation coefficient r (-1 to +1)
  const getCellColor = (r) => {
    if (r === null || r === undefined) return 'transparent';
    if (r > 0) {
      // Positive correlation -> Rose / Crimson
      const alpha = Math.min(Math.abs(r) * 0.85 + 0.1, 0.95);
      return `rgba(225, 29, 72, ${alpha})`;
    } else if (r < 0) {
      // Negative correlation -> Sky / Indigo
      const alpha = Math.min(Math.abs(r) * 0.85 + 0.1, 0.95);
      return `rgba(14, 165, 233, ${alpha})`;
    }
    return 'rgba(30, 41, 59, 0.3)';
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <div>
          <h4 className="text-sm font-bold text-slate-200 uppercase tracking-wider">
            Physicochemical Feature Correlation Matrix
          </h4>
          <p className="text-xs text-slate-400">
            Pearson correlation coefficient (r) between all numerical features.
          </p>
        </div>

        {/* Legend */}
        <div className="flex items-center space-x-3 text-xs">
          <div className="flex items-center gap-1.5">
            <div className="w-3 h-3 rounded bg-sky-500" />
            <span className="text-slate-400">-1.0 (Negative)</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-3 h-3 rounded bg-slate-700" />
            <span className="text-slate-400">0.0</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-3 h-3 rounded bg-rose-500" />
            <span className="text-slate-400">+1.0 (Positive)</span>
          </div>
        </div>
      </div>

      <div className="overflow-x-auto pb-2">
        <div className="inline-block min-w-full">
          <table className="border-collapse text-[11px]">
            <thead>
              <tr>
                <th className="p-2 text-left font-semibold text-slate-500 bg-slate-900/50 sticky left-0 z-10">
                  Feature
                </th>
                {columns.map((col, idx) => (
                  <th
                    key={idx}
                    className="p-2 text-center font-semibold text-slate-400 whitespace-nowrap min-w-[70px]"
                    title={col}
                  >
                    <div className="truncate max-w-[85px]">{col}</div>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {matrix.map((rowObj, rIdx) => {
                const rowName = rowObj.name;
                const rowVals = rowObj.values;

                return (
                  <tr key={rIdx} className="hover:bg-slate-800/30">
                    <td className="p-2 font-medium text-slate-300 whitespace-nowrap bg-slate-900/80 sticky left-0 z-10 border-r border-slate-800">
                      {rowName}
                    </td>

                    {rowVals.map((val, cIdx) => {
                      const colName = columns[cIdx];
                      const isHovered =
                        hoveredCell && hoveredCell.r === rIdx && hoveredCell.c === cIdx;

                      return (
                        <td
                          key={cIdx}
                          onMouseEnter={() => setHoveredCell({ r: rIdx, c: cIdx, val, rowName, colName })}
                          onMouseLeave={() => setHoveredCell(null)}
                          className="p-2 text-center font-mono font-bold transition-all relative border border-slate-800/40 cursor-default"
                          style={{
                            backgroundColor: getCellColor(val),
                            color: Math.abs(val) > 0.35 ? '#ffffff' : '#cbd5e1',
                          }}
                        >
                          {Number(val).toFixed(2)}
                          {isHovered && (
                            <div className="absolute inset-0 border-2 border-white pointer-events-none" />
                          )}
                        </td>
                      );
                    })}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {hoveredCell && (
        <div className="p-3 rounded-xl bg-slate-800/90 border border-slate-700 text-xs text-slate-300 flex items-center justify-between">
          <span>
            Correlation between <strong className="text-rose-400">{hoveredCell.rowName}</strong> and{' '}
            <strong className="text-sky-400">{hoveredCell.colName}</strong>:
          </span>
          <span className="font-mono font-bold text-sm text-white px-2 py-0.5 rounded bg-slate-900">
            r = {Number(hoveredCell.val).toFixed(3)}
          </span>
        </div>
      )}
    </div>
  );
}
