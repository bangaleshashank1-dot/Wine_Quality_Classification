import React, { useEffect, useState } from 'react';
import { CheckCircle2, Loader2 } from 'lucide-react';

export default function TrainingModal({ isOpen, isTraining, onComplete }) {
  const [currentStep, setCurrentStep] = useState(0);

  const steps = [
    { label: 'Preparing Dataset...', duration: 400 },
    { label: 'Preprocessing & Scaling (StandardScaler)...', duration: 500 },
    { label: 'Training Logistic Regression (Binary Model)...', duration: 700 },
    { label: 'Training Multinomial Logistic Regression (Multi-Class Softmax)...', duration: 800 },
    { label: 'Calculating Dynamic Metrics & ROC Curves...', duration: 500 },
    { label: 'Completed!', duration: 300 },
  ];

  useEffect(() => {
    if (isOpen && isTraining) {
      setCurrentStep(0);
      let stepIndex = 0;

      const runTimer = () => {
        if (stepIndex < steps.length - 1) {
          stepIndex += 1;
          setCurrentStep(stepIndex);
          timeoutId = setTimeout(runTimer, steps[stepIndex].duration);
        }
      };

      let timeoutId = setTimeout(runTimer, steps[0].duration);
      return () => clearTimeout(timeoutId);
    }
  }, [isOpen, isTraining]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-4 animate-in fade-in">
      <div className="w-full max-w-md p-6 rounded-3xl bg-slate-900 border border-slate-700/80 shadow-2xl shadow-rose-950/50 space-y-6">
        <div className="text-center space-y-2">
          <div className="w-14 h-14 mx-auto rounded-2xl bg-rose-500/15 border border-rose-500/30 flex items-center justify-center text-3xl">
            🍷
          </div>
          <h3 className="text-lg font-bold text-slate-100">
            {isTraining ? 'Training Machine Learning Models' : 'Training Finished!'}
          </h3>
          <p className="text-xs text-slate-400">
            Training Logistic Regression and Multinomial Logistic Regression on your data.
          </p>
        </div>

        {/* Stepper */}
        <div className="space-y-3">
          {steps.map((step, idx) => {
            const isDone = idx < currentStep || (!isTraining && idx <= currentStep);
            const isCurrent = idx === currentStep && isTraining;

            return (
              <div
                key={idx}
                className={`flex items-center space-x-3 p-2.5 rounded-xl border transition-all text-xs ${
                  isCurrent
                    ? 'bg-rose-500/10 border-rose-500/30 text-rose-300 font-semibold'
                    : isDone
                    ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-300'
                    : 'bg-slate-800/30 border-slate-800 text-slate-500'
                }`}
              >
                {isDone ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                ) : isCurrent ? (
                  <Loader2 className="w-4 h-4 text-rose-400 animate-spin flex-shrink-0" />
                ) : (
                  <div className="w-4 h-4 rounded-full border border-slate-700 flex-shrink-0" />
                )}
                <span>{step.label}</span>
              </div>
            );
          })}
        </div>

        {!isTraining && (
          <button
            onClick={onComplete}
            className="w-full py-3 rounded-2xl bg-gradient-to-r from-rose-600 to-pink-600 hover:from-rose-500 hover:to-pink-500 text-white font-bold text-sm shadow-lg shadow-rose-600/30 transition-all"
          >
            Explore Trained Results →
          </button>
        )}
      </div>
    </div>
  );
}
