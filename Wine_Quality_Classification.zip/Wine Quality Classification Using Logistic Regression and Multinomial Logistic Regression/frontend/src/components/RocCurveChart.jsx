import React from 'react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  ReferenceLine
} from 'recharts';

export default function RocCurveChart({ rocPoints, aucValue, isDark = true }) {
  if (!rocPoints || rocPoints.length === 0) {
    return (
      <div className="h-64 flex items-center justify-center text-slate-500 text-sm italic">
        Train the model to view the ROC curve.
      </div>
    );
  }

  // Ensure 0,0 and 1,1 boundaries are present
  const sortedPoints = [...rocPoints].sort((a, b) => a.fpr - b.fpr);
  if (sortedPoints[0].fpr !== 0) sortedPoints.unshift({ fpr: 0, tpr: 0 });
  if (sortedPoints[sortedPoints.length - 1].fpr !== 1) sortedPoints.push({ fpr: 1, tpr: 1 });

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <div>
          <h4 className="text-sm font-bold text-slate-200 uppercase tracking-wider">
            Receiver Operating Characteristic (ROC) Curve
          </h4>
          <p className="text-xs text-slate-400">
            Discriminative ability of Logistic Regression across decision thresholds
          </p>
        </div>
        <div className="flex items-center space-x-2">
          <span className="text-xs text-slate-400">ROC-AUC:</span>
          <span className="px-3 py-1 rounded-xl bg-gradient-to-r from-rose-600 to-pink-600 text-white font-mono font-bold text-sm shadow-md shadow-rose-600/30">
            {aucValue !== undefined ? Number(aucValue).toFixed(4) : 'N/A'}
          </span>
        </div>
      </div>

      <div className="h-72 w-full pt-2">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={sortedPoints} margin={{ top: 10, right: 20, left: 0, bottom: 20 }}>
            <defs>
              <linearGradient id="rocGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#e11d48" stopOpacity={0.4} />
                <stop offset="95%" stopColor="#e11d48" stopOpacity={0.0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke={isDark ? '#334155' : '#e2e8f0'} opacity={0.5} />
            <XAxis
              dataKey="fpr"
              type="number"
              domain={[0, 1]}
              tickCount={6}
              stroke={isDark ? '#94a3b8' : '#64748b'}
              tick={{ fontSize: 11 }}
              label={{
                value: 'False Positive Rate (1 - Specificity)',
                position: 'insideBottom',
                offset: -10,
                fill: isDark ? '#cbd5e1' : '#475569',
                fontSize: 12,
              }}
            />
            <YAxis
              type="number"
              domain={[0, 1]}
              tickCount={6}
              stroke={isDark ? '#94a3b8' : '#64748b'}
              tick={{ fontSize: 11 }}
              label={{
                value: 'True Positive Rate (Sensitivity / Recall)',
                angle: -90,
                position: 'insideLeft',
                offset: 15,
                fill: isDark ? '#cbd5e1' : '#475569',
                fontSize: 12,
              }}
            />
            <Tooltip
              content={({ active, payload }) => {
                if (active && payload && payload.length) {
                  const data = payload[0].payload;
                  return (
                    <div className="p-3 rounded-xl bg-slate-900 border border-slate-700 text-slate-100 shadow-xl text-xs space-y-1">
                      <div className="font-semibold text-rose-400">Decision Threshold Operating Point</div>
                      <div className="flex justify-between gap-4">
                        <span className="text-slate-400">False Positive Rate (FPR):</span>
                        <span className="font-mono font-bold text-slate-200">{Number(data.fpr).toFixed(4)}</span>
                      </div>
                      <div className="flex justify-between gap-4">
                        <span className="text-slate-400">True Positive Rate (TPR):</span>
                        <span className="font-mono font-bold text-emerald-400">{Number(data.tpr).toFixed(4)}</span>
                      </div>
                    </div>
                  );
                }
                return null;
              }}
            />
            {/* Random guess baseline */}
            <ReferenceLine
              segment={[{ x: 0, y: 0 }, { x: 1, y: 1 }]}
              stroke="#64748b"
              strokeDasharray="4 4"
              label={{
                value: 'Random Guess (AUC=0.50)',
                position: 'center',
                fill: '#94a3b8',
                fontSize: 10,
              }}
            />
            <Area
              type="monotone"
              dataKey="tpr"
              stroke="#e11d48"
              strokeWidth={3}
              fillOpacity={1}
              fill="url(#rocGradient)"
              name="ROC Curve"
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      <div className="text-center text-[11px] text-slate-400 italic">
        An AUC closer to 1.0 indicates superior discrimination between Good and Poor wine.
      </div>
    </div>
  );
}
