import React from 'react';

export default function MetricCard({
  title,
  value,
  subtitle,
  icon: Icon,
  trend,
  color = 'rose',
  isDark = true
}) {
  const colorMap = {
    rose: {
      border: 'border-rose-500/20',
      text: 'text-rose-400',
      bg: 'from-rose-500/10 to-transparent',
      iconBg: 'bg-rose-500/15 text-rose-400',
    },
    emerald: {
      border: 'border-emerald-500/20',
      text: 'text-emerald-400',
      bg: 'from-emerald-500/10 to-transparent',
      iconBg: 'bg-emerald-500/15 text-emerald-400',
    },
    amber: {
      border: 'border-amber-500/20',
      text: 'text-amber-400',
      bg: 'from-amber-500/10 to-transparent',
      iconBg: 'bg-amber-500/15 text-amber-400',
    },
    indigo: {
      border: 'border-indigo-500/20',
      text: 'text-indigo-400',
      bg: 'from-indigo-500/10 to-transparent',
      iconBg: 'bg-indigo-500/15 text-indigo-400',
    },
    sky: {
      border: 'border-sky-500/20',
      text: 'text-sky-400',
      bg: 'from-sky-500/10 to-transparent',
      iconBg: 'bg-sky-500/15 text-sky-400',
    },
    purple: {
      border: 'border-purple-500/20',
      text: 'text-purple-400',
      bg: 'from-purple-500/10 to-transparent',
      iconBg: 'bg-purple-500/15 text-purple-400',
    },
  };

  const scheme = colorMap[color] || colorMap.rose;

  return (
    <div className={`p-5 rounded-2xl border transition-all duration-200 bg-gradient-to-br ${scheme.bg} ${
      isDark ? 'bg-slate-900/60 border-slate-800/80 hover:border-slate-700' : 'bg-white border-slate-200 shadow-sm'
    } relative overflow-hidden group`}>
      <div className="flex items-start justify-between">
        <div className="space-y-1">
          <span className="text-xs font-semibold text-slate-400 tracking-wide uppercase">
            {title}
          </span>
          <div className="text-3xl font-extrabold tracking-tight text-slate-100 font-mono">
            {value}
          </div>
          {subtitle && (
            <p className="text-xs text-slate-400 font-medium">
              {subtitle}
            </p>
          )}
        </div>

        {Icon && (
          <div className={`p-3 rounded-xl ${scheme.iconBg} flex items-center justify-center transition-transform group-hover:scale-110 duration-200`}>
            <Icon className="w-5 h-5" />
          </div>
        )}
      </div>

      {trend && (
        <div className="mt-3 pt-3 border-t border-slate-800/60 flex items-center text-xs font-medium text-slate-400">
          {trend}
        </div>
      )}
    </div>
  );
}
