import axios from 'axios';

// Vite proxy forwards /api to http://127.0.0.1:8000
const API_BASE = '/api';

const apiClient = axios.create({
  baseURL: API_BASE,
  timeout: 60000,
});

export const api = {
  checkHealth: async () => {
    const res = await apiClient.get('/health');
    return res.data;
  },

  uploadDataset: async (file) => {
    const formData = new FormData();
    formData.append('file', file);
    const res = await apiClient.post('/upload', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
    return res.data;
  },

  loadSampleDataset: async (sampleType = 'red') => {
    const res = await apiClient.post('/load-sample', { sample_type: sampleType });
    return res.data;
  },

  getDataset: async () => {
    const res = await apiClient.get('/dataset');
    return res.data;
  },

  getDatasetPreview: async (page = 1, pageSize = 25, search = '') => {
    const res = await apiClient.get('/dataset/preview', {
      params: { page, page_size: pageSize, search },
    });
    return res.data;
  },

  selectTarget: async (targetColumn) => {
    const res = await apiClient.post('/select-target', { target_column: targetColumn });
    return res.data;
  },

  preprocessData: async (removeDuplicates = true, testSize = 0.2, randomState = 42) => {
    const res = await apiClient.post('/preprocess', {
      remove_duplicates: removeDuplicates,
      test_size: testSize,
      random_state: randomState,
    });
    return res.data;
  },

  trainModels: async (threshold = 6.0, maxIter = 1000) => {
    const res = await apiClient.post('/train', {
      threshold: parseFloat(threshold),
      max_iter: parseInt(maxIter, 10),
    });
    return res.data;
  },

  getLogisticResults: async () => {
    const res = await apiClient.get('/results/logistic');
    return res.data;
  },

  getMultinomialResults: async () => {
    const res = await apiClient.get('/results/multinomial');
    return res.data;
  },

  getModelComparison: async () => {
    const res = await apiClient.get('/results/comparison');
    return res.data;
  },

  predictWine: async (features) => {
    const res = await apiClient.post('/predict', { features });
    return res.data;
  },

  getPredictionPresets: async () => {
    const res = await apiClient.get('/predict/presets');
    return res.data;
  },

  getCorrelation: async () => {
    const res = await apiClient.get('/visualizations/correlation');
    return res.data;
  },

  getDistributions: async () => {
    const res = await apiClient.get('/visualizations/distributions');
    return res.data;
  },

  getDownloadProcessedUrl: () => `${API_BASE}/download/processed`,
  getDownloadReportUrl: () => `${API_BASE}/download/report`,
};
