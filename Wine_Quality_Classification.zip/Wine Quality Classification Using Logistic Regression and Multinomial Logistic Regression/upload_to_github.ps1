# ============================================================
#  WINE QUALITY CLASSIFICATION - GitHub Upload Script
#  Repository: bangaleshashank1-dot/Wine_Quality_Classification
#  Target:     PROJECT CODE/
# ============================================================

$ErrorActionPreference = "Stop"

# --- Configuration ---
$REPO_URL    = "https://github.com/bangaleshashank1-dot/Wine_Quality_Classification.git"
$BRANCH      = "main"
$PROJECT_DIR = $PSScriptRoot
$TEMP_DIR    = Join-Path (Split-Path $PROJECT_DIR) "temp_wine_repo"
$TARGET_DIR  = Join-Path $TEMP_DIR "PROJECT CODE"
$COMMIT_MSG  = "Add complete Wine Quality Classification project code (Frontend + Backend + Datasets)"

# --- Colors ---
function Write-Step($num, $msg) {
    Write-Host ""
    Write-Host "[$num] $msg" -ForegroundColor Cyan
    Write-Host ("=" * 60) -ForegroundColor DarkGray
}

function Write-OK($msg)   { Write-Host "  OK  $msg" -ForegroundColor Green }
function Write-Info($msg)  { Write-Host "  >>  $msg" -ForegroundColor Yellow }
function Write-Err($msg)   { Write-Host "  !!  $msg" -ForegroundColor Red }

# ============================================================
Write-Host ""
Write-Host "============================================================" -ForegroundColor Magenta
Write-Host "   WINE QUALITY CLASSIFICATION - GitHub Upload" -ForegroundColor Magenta
Write-Host "   Repository: bangaleshashank1-dot/Wine_Quality_Classification" -ForegroundColor Magenta
Write-Host "   Target Folder: PROJECT CODE/" -ForegroundColor Magenta
Write-Host "============================================================" -ForegroundColor Magenta

# ============================================================
# STEP 1: Verify git is installed
# ============================================================
Write-Step "1/7" "Checking prerequisites..."

try {
    $gitVersion = git --version 2>&1
    Write-OK "Git found: $gitVersion"
} catch {
    Write-Err "Git is not installed! Install it from https://git-scm.com/downloads"
    exit 1
}

# Check git config
$userName  = git config user.name 2>$null
$userEmail = git config user.email 2>$null
if ($userName -and $userEmail) {
    Write-OK ("Git user: {0} ({1})" -f $userName, $userEmail)
} else {
    Write-Err "Git user not configured. Run:"
    Write-Host '  git config --global user.name "Your Name"'
    Write-Host '  git config --global user.email "your@email.com"'
    exit 1
}

# ============================================================
# STEP 2: Clean up any previous temp repo
# ============================================================
Write-Step "2/7" "Preparing workspace..."

if (Test-Path $TEMP_DIR) {
    Write-Info "Removing previous temp clone at: $TEMP_DIR"
    Remove-Item -Recurse -Force $TEMP_DIR
}
Write-OK "Workspace clean"

# ============================================================
# STEP 3: Clone the existing repository
# ============================================================
Write-Step "3/7" "Cloning existing repository..."
Write-Info "URL: $REPO_URL"

git clone $REPO_URL $TEMP_DIR
if ($LASTEXITCODE -ne 0) {
    Write-Err "Failed to clone repository. Check your internet connection and repo URL."
    exit 1
}
Write-OK "Repository cloned to: $TEMP_DIR"

# ============================================================
# STEP 4: Copy project files into PROJECT CODE/
# ============================================================
Write-Step "4/7" "Copying project files into PROJECT CODE folder..."

# Create target directory
New-Item -ItemType Directory -Force -Path $TARGET_DIR | Out-Null

# Define what to EXCLUDE from copying
$excludeDirs  = @("node_modules", "dist", "dist-ssr", "__pycache__", ".git",
                   "saved_models", ".vscode", ".idea", ".agents", "temp_wine_repo")
$excludeFiles = @("*.pyc", "*.pyo", "*.log", "*.local", "*.suo",
                   "upload_to_github.ps1")

# Copy files recursively, excluding junk
function Copy-ProjectFiles($source, $destination) {
    if (-not (Test-Path $destination)) {
        New-Item -ItemType Directory -Force -Path $destination | Out-Null
    }

    Get-ChildItem -Path $source -File | ForEach-Object {
        $skip = $false
        foreach ($pattern in $excludeFiles) {
            if ($_.Name -like $pattern) { $skip = $true; break }
        }
        if ($_.Name -eq "upload_to_github.ps1") { $skip = $true }
        if (-not $skip) {
            Copy-Item $_.FullName -Destination $destination -Force
        }
    }

    Get-ChildItem -Path $source -Directory | ForEach-Object {
        if ($excludeDirs -notcontains $_.Name) {
            $newDest = Join-Path $destination $_.Name
            Copy-ProjectFiles $_.FullName $newDest
        }
    }
}

Copy-ProjectFiles $PROJECT_DIR $TARGET_DIR

$fileCount = (Get-ChildItem -Path $TARGET_DIR -Recurse -File).Count
Write-OK "$fileCount files copied into PROJECT CODE/"

# ============================================================
# STEP 5: Create .gitignore inside PROJECT CODE/
# ============================================================
Write-Step "5/7" "Ensuring .gitignore is in place..."

$gitignoreLines = @(
    "# ===== Python ====="
    "__pycache__/"
    "*.py[cod]"
    "*.so"
    "*.egg-info/"
    "dist/"
    "build/"
    "*.egg"
    ".eggs/"
    "*.whl"
    "venv/"
    "env/"
    ".venv/"
    ".env/"
    ""
    "# ===== Node.js ====="
    "node_modules/"
    "npm-debug.log*"
    "yarn-debug.log*"
    "yarn-error.log*"
    "pnpm-debug.log*"
    ""
    "# ===== Build Output ====="
    "frontend/dist/"
    "frontend/dist-ssr/"
    ""
    "# ===== IDE / Editor ====="
    ".vscode/"
    ".idea/"
    "*.suo"
    "*.ntvs*"
    "*.njsproj"
    "*.sln"
    "*.sw?"
    ".DS_Store"
    "Thumbs.db"
    ""
    "# ===== Saved ML Models ====="
    "backend/saved_models/*.joblib"
    ""
    "# ===== Local / Temp ====="
    "*.local"
    "*.log"
    ".agents/"
)

$gitignorePath = Join-Path $TARGET_DIR ".gitignore"
$gitignoreLines | Out-File -FilePath $gitignorePath -Encoding UTF8
Write-OK ".gitignore created"

# ============================================================
# STEP 6: Stage and Commit
# ============================================================
Write-Step "6/7" "Staging and committing files..."

Push-Location $TEMP_DIR
git add .
Write-OK "All files staged"

# Check if there are changes to commit
$status = git status --porcelain 2>&1
if (-not $status) {
    Write-Info "No changes detected - your repo is already up to date!"
    Pop-Location
    Remove-Item -Recurse -Force $TEMP_DIR
    Write-OK "Done! Nothing to push."
    exit 0
}

git commit -m $COMMIT_MSG
if ($LASTEXITCODE -ne 0) {
    Write-Err "Commit failed!"
    Pop-Location
    exit 1
}
Write-OK "Changes committed"

Write-Host ""
Write-Info "Files to be pushed:"
git diff --stat HEAD~1 2>$null
Write-Host ""

# ============================================================
# STEP 7: Push to GitHub
# ============================================================
Write-Step "7/7" "Pushing to GitHub..."
Write-Info "Pushing to: $REPO_URL (branch: $BRANCH)"
Write-Host ""
Write-Host "  If prompted, enter your GitHub credentials:" -ForegroundColor Yellow
Write-Host "    Username: your GitHub username" -ForegroundColor Yellow
Write-Host "    Password: your Personal Access Token (NOT your password)" -ForegroundColor Yellow
Write-Host ""

git push origin $BRANCH
if ($LASTEXITCODE -ne 0) {
    Write-Err "Push failed! Check your authentication."
    Write-Host ""
    Write-Host "  To fix authentication, try one of these:" -ForegroundColor Yellow
    Write-Host "    1. Install GitHub CLI:  winget install GitHub.cli" -ForegroundColor Yellow
    Write-Host "       Then run:            gh auth login" -ForegroundColor Yellow
    Write-Host "    2. Create a Personal Access Token at:" -ForegroundColor Yellow
    Write-Host "       https://github.com/settings/tokens" -ForegroundColor Yellow
    Write-Host "       Select repo scope, then use the token as password" -ForegroundColor Yellow
    Pop-Location
    exit 1
}

Pop-Location
Write-OK "Successfully pushed to GitHub!"

# ============================================================
# Cleanup
# ============================================================
Write-Host ""
Write-Info "Cleaning up temp directory..."
Remove-Item -Recurse -Force $TEMP_DIR
Write-OK "Temp directory removed"

# ============================================================
# DONE
# ============================================================
Write-Host ""
Write-Host "============================================================" -ForegroundColor Green
Write-Host "   UPLOAD COMPLETE!" -ForegroundColor Green
Write-Host "============================================================" -ForegroundColor Green
Write-Host ""
Write-Host "  View your code at:" -ForegroundColor White
Write-Host "  https://github.com/bangaleshashank1-dot/Wine_Quality_Classification/tree/main/PROJECT%20CODE" -ForegroundColor Cyan
Write-Host ""
Write-Host "  Your repo now contains:" -ForegroundColor White
Write-Host "    - README.md (full project documentation)" -ForegroundColor White
Write-Host "    - backend/ (FastAPI + ML engine + UCI datasets)" -ForegroundColor White
Write-Host "    - frontend/ (React + Vite source code)" -ForegroundColor White
Write-Host "    - test_e2e.py, test_excel.py (automated tests)" -ForegroundColor White
Write-Host "    - .gitignore (keeps repo clean)" -ForegroundColor White
Write-Host ""
