# Wine Quality Classification Using Logistic Regression and Multinomial Logistic Regression

[![B.Tech Project](https://img.shields.io/badge/Degree-B.Tech%20Machine%20Learning-crimson.svg)](#)
[![FastAPI](https://img.shields.io/badge/Backend-FastAPI%20Python-009688.svg?logo=fastapi)](#)
[![React](https://img.shields.io/badge/Frontend-React%20%2B%20Vite%20%2B%20Tailwind-61DAFB.svg?logo=react)](#)
[![Scikit-Learn](https://img.shields.io/badge/ML%20Engine-Scikit--Learn%20%2B%20Pandas-F7931E.svg?logo=scikit-learn)](#)

A modern, professional, and fully functional end-to-end Machine Learning web application developed for **B.Tech Machine Learning Project Demonstration and Viva Examination**.

---

## 👥 Project Information

* **Project Title**: Wine Quality Classification Using Logistic Regression and Multinomial Logistic Regression
* **Degree**: Bachelor of Technology (B.Tech)
* **Course**: Machine Learning
* **Academic Year**: 2026-27
* **Department**: Department of Computer Science and Information Technology (CSIT)

### 🎓 Students
* **S. Venugopal** — Roll No: **2520090185**
* **Shashank Bangale** — Roll No: **2520090086**

### 👩‍🏫 Project Guide & Supervisor
* **I V Sai Lakshmi Haritha**, Assistant Professor, Department of CSIT

---

## 🌟 Key Features

1. **Dual Machine Learning Engine**:
   * **Binary Logistic Regression**: Classifies wine into **Good** ($\ge 6$) vs **Poor** ($< 6$) with configurable thresholding. Generates Accuracy, Precision, Recall, F1-Score, Confusion Matrix, and interactive ROC Curves with exact AUC calculation.
   * **Multinomial Logistic Regression**: Multi-class classification across all distinct detected quality grades ($3, 4, 5, 6, 7, 8$) using Softmax activation. Generates Macro and Weighted metrics, multi-class confusion matrix, and class-wise breakdown.
2. **Dynamic Data Processing**:
   * Accepts both **CSV** (`.csv`) and **Excel** (`.xlsx`, `.xls`) files via drag-and-drop or file browser.
   * Automatic case-insensitive target column detection (`quality`, `Quality`, `QUALITY`) with manual dropdown fallback.
   * Pre-packaged authentic **UCI Wine Quality Datasets** (Red & White wine in CSV and Excel formats) available for immediate 1-click loading.
3. **Rigorous 6-Step Automated Preprocessing**:
   * **Step 1**: Missing value check & imputation (Median for numeric, Mode for categorical).
   * **Step 2**: Duplicate row identification and removal with before/after statistics.
   * **Step 3**: Feature matrix ($X$) and target vector ($y$) separation.
   * **Step 4**: Categorical dummy encoding (if categorical features exist).
   * **Step 5**: 80/20 Train-Test split with fixed `random_state=42` for reproducibility.
   * **Step 6**: Feature scaling via `StandardScaler` ($z = \frac{x - \mu}{\sigma}$).
4. **Interactive Exploratory Visualizations**:
   * Quality score frequency distribution bar chart.
   * Chemical feature histogram with dynamic feature selector.
   * Interactive 2D Pearson Correlation Heatmap with hover tooltips and intensity color scaling.
5. **Real-Time Wine Quality Predictor**:
   * Dynamically generates numerical inputs based on detected dataset features with min/max hints.
   * One-click presets: *Good Wine Preset*, *Poor Wine Preset*, and *Dataset Average*.
   * Generates binary prediction (*GOOD / POOR*) with confidence percentage, multi-class quality rating, and full probability distribution bars.
6. **Exports & Reporting**:
   * Export cleaned preprocessed dataset as CSV.
   * Download comprehensive academic project evaluation report as text.
7. **Viva & Defense Guide**:
   * Built-in student-friendly explanations for all ML concepts.
   * Top 5 frequently asked viva defense questions and model answers.

---

## 🏗️ Architecture & Technology Stack

```mermaid
graph LR
    User[User / Examiner] --> UI[React + Vite + Tailwind CSS]
    UI -->|REST API / Axios| API[FastAPI Backend Server]
    API --> DP[DataProcessor Module]
    DP --> ML[Scikit-Learn ML Engine]
    ML --> Bin[Binary Logistic Regression]
    ML --> Multi[Multinomial Logistic Regression]
    Bin & Multi --> Eval[Evaluation & ROC Engine]
    Eval --> UI
    UI --> Inf[Inference Tool with Scaler]
```

### Technology Stack:
* **Frontend**: React 19, Vite, Tailwind CSS v4, Lucide React, Recharts, Axios.
* **Backend**: Python 3.10+, FastAPI, Uvicorn, Python-Multipart.
* **Machine Learning**: Scikit-learn, Pandas, NumPy, Joblib, Openpyxl.

---

## 🚀 Quick Start & Installation

### 1. Prerequisites
* Python 3.10 or newer
* Node.js v18+ and npm

### 2. Backend Setup
Navigate to the `backend/` directory and install the Python dependencies:

```bash
cd backend
python -m pip install -r requirements.txt
```

Start the FastAPI server:

```bash
python -m uvicorn main:app --host 127.0.0.1 --port 8000 --reload
```

The API will be available at `http://127.0.0.1:8000`. You can inspect the interactive OpenAPI documentation at `http://127.0.0.1:8000/docs`.

### 3. Frontend Setup
Open a new terminal, navigate to the `frontend/` directory, and install dependencies:

```bash
cd frontend
npm install
```

Start the Vite development server:

```bash
npm run dev
```

Open your browser and navigate to:
👉 **`http://127.0.0.1:5173/`**

---

## 📖 Step-by-Step Demonstration Guide (For Viva / Demo)

1. **Dashboard**:
   * Open `http://127.0.0.1:5173/`. Observe the project title, B.Tech ML banner, workflow pipeline, and empty state cards.
2. **Dataset Loading**:
   * Click **"Load UCI Sample Data"** in the top bar (or drag-and-drop your own CSV/Excel file).
   * Notice the application automatically detects the target column `quality` and shows the 10-row preview, missing values, duplicates, and column statistics.
   * Click **"View Full Dataset"** to browse and search records with pagination.
3. **Preprocessing**:
   * Click **"Preprocessing"** in the sidebar. Inspect the before/after row counts (e.g. 1,599 $\rightarrow$ 1,359 rows after duplicate removal) and view the fitted `StandardScaler` mean ($\mu$) and standard deviation ($\sigma$).
   * Click **"Download Preprocessed CSV"** to save the sanitized data.
4. **Train Models**:
   * Click **"Start Machine Learning Analysis"** or **"Train Models"**.
   * Observe the live step-by-step training progress animation.
5. **Binary Classification**:
   * Inspect the Logistic Regression Accuracy, Precision, Recall, F1-Score, and ROC-AUC.
   * Review the Confusion Matrix (True Positives, False Positives, True Negatives, False Negatives) and the interactive ROC Curve.
   * Try changing the threshold (e.g. to $\ge 5$ or $\ge 7$) and click **"Apply & Retrain"**.
6. **Multi-Class Classification**:
   * Navigate to **"Multi-Class ML"**. Examine the exact accuracy and weighted/macro metrics across all individual quality levels ($3, 4, 5, 6, 7, 8$).
   * Inspect the dynamic $N \times N$ multi-class confusion matrix.
7. **Model Comparison**:
   * Click **"Model Comparison"** to review the side-by-side benchmark table and grouped bar chart.
   * Read the dynamically generated verdict explaining which model performs better and why.
8. **Wine Prediction**:
   * Click **"Wine Prediction"**. Click **"Good Wine Preset"** or enter laboratory measurements.
   * Click **"Predict Wine Quality"** to see real-time inference:
     * Binary category (*GOOD / POOR*) with confidence rating.
     * Exact predicted quality score with horizontal probability distribution bars.
9. **Visualizations**:
   * Navigate to **"Visualizations"** to view the target class distribution, histogram feature explorer, and the 2D correlation heatmap.
10. **About & Viva**:
    * Review student names (**S. Venugopal**, **Shashank Bangale**), supervisor (**I V Sai Lakshmi Haritha**), theoretical ML equations, and the Viva FAQ cheat-sheet.
11. **Download Report**:
    * Click **"Download Project Evaluation Report"** to export the complete analysis as a text file.

---

## 🧪 Automated Testing

To run the automated end-to-end integration test verifying all backend routes, file upload, preprocessing, model training, prediction, and report generation:

```bash
python test_e2e.py
python test_excel.py
```

---

## 📄 License
Academic project demonstration for B.Tech Machine Learning course, Academic Year 2026-27.
